import google.generativeai as genai
import PIL.Image
import os
import ssl
ssl._create_default_https_context = ssl._create_unverified_context
import grpc
import certifi
# def checkServerIdentity(host, cert):
#      authContext = newAuthContextFromPem(cert)
#      if authContext.name != expectedName or authContext.environment != myEnvironment:
#         return False
#      return True

# grpc.ssl_channel_credentials(
#     clientTrust.encode('utf-8'),
#     open(clientKeystore[1]).read().encode('utf-8'),
#     open(clientKeystore[0]).read().encode('utf-8'),
#     {
#       "insecureSkipHostnameVerify": True,
#       "checkServerIdentity": checkServerIdentity
#     })

import os, ssl
# if (not os.environ.get('PYTHONHTTPSVERIFY', '') and getattr(ssl, '_create_unverified_context', None)):
#     ssl._create_default_https_context
#  = ssl._create_unverified_context
# + rest
# 2) HTTPAdapter, verify->false
    # def send(self, request, stream=False, timeout=None, verify=False, cert=None, proxies=None):

# 3)     def request(self, method, url,
#             params=None, data=None, headers=None, cookies=None, files=None,
#             auth=None, timeout=None, allow_redirects=True, proxies=None,
#             hooks=None, stream=None, verify=None, cert=None, json=None):
genai.configure(api_key=os.environ["API_KEY"],transport="rest")
# img = PIL.Image.open('image.png')
# # os.environ["GRPC_DEFAULT_SSL_ROOTS_FILE_PATH"] = certifi.where()
# model = genai.GenerativeModel(model_name="gemini-1.5-flash")
# response = model.generate_content(["What is in this photo?"],
#                                   request_options=None)
# print(response.text)

model = genai.GenerativeModel("gemini-1.5-flash")
response = model.generate_content("Write a story about a magic backpack.")
print(response.text)