CE&CSI 联合设计
1. 具体方案设计部分，请参考./solution_details.pdf
2. 训练过程，请参考 ./proj_introduction.pdf
配置部分：
1. 暂未完成docker配置
2. 主要环境为：python3.7.3 + torch1.9.0 + CUDA11.1@A6000 GPU

更细节的python包请参考piplist.txt

