'''
The content of this file could be self-defined. 
But please note the interface of the following function cannot be modified,
	- encFunction_1
	- decFunction_1
	- encFunction_2
	- decFunction_2
'''
#=======================================================================================================================
#=======================================================================================================================
# Package Importing
import numpy as np
import torch
from torch import nn
from torch.utils.data import Dataset
from einops import rearrange
from einops.layers.torch import Rearrange
from torch import Tensor
import math
import os 
import random


def seed_torch(seed=0):
	random.seed(seed)
	os.environ['PYTHONHASHSEED'] = str(seed)
	np.random.seed(seed)
	torch.manual_seed(seed)
	torch.cuda.manual_seed(seed)
	torch.backends.cudnn.benchmark = True
	torch.backends.cudnn.deterministic = True

def gumbel_sigmoid(logits: Tensor, tau: float = 0.5, hard: bool = False, threshold: float = 0.5, gumbel_noise=2.0) -> Tensor:
	"""
	Samples from the Gumbel-Sigmoid distribution and optionally discretizes.
	The discretization converts the values greater than `threshold` to 1 and the rest to 0.
	The code is adapted from the official PyTorch implementation of gumbel_softmax:
	https://pytorch.org/docs/stable/_modules/torch/nn/functional.html#gumbel_softmax
	Args:
	  logits: `[..., num_features]` unnormalized log probabilities
	  tau: non-negative scalar temperature
	  hard: if ``True``, the returned samples will be discretized,
			but will be differentiated as if it is the soft sample in autograd
	 threshold: threshold for the discretization,
				values greater than this will be set to 1 and the rest to 0
	Returns:
	  Sampled tensor of same shape as `logits` from the Gumbel-Sigmoid distribution.
	  If ``hard=True``, the returned samples are descretized according to `threshold`, otherwise they will
	  be probability distributions.
	"""
	gumbels = (
		-torch.empty_like(logits, memory_format=torch.legacy_contiguous_format).exponential_().log()
	)*gumbel_noise  # ~Gumbel(0, 1)
	gumbels = (logits + gumbels) / tau  # ~Gumbel(logits, tau)
	
	y_soft = gumbels.sigmoid()
	if hard:
		# y_soft = logits.sigmoid()
		# Straight through.
		indices = (y_soft > threshold).nonzero(as_tuple=True)
		y_hard = torch.zeros_like(logits, memory_format=torch.legacy_contiguous_format)
		y_hard[indices[0], indices[1]] = 1.0
		ret = y_hard - y_soft.detach() + y_soft
	else:
		# Reparametrization trick.
		ret = y_soft
	return ret


# class DatasetFolder_higher_eval(Dataset):
# 	def __init__(self, data):
# 		data_complex = data[:, 0, ...] + 1j * data[:, 1, ...]
# 		data_2order = data_complex * (np.abs(data_complex) ** 2)
# 		data_complex = np.concatenate([data_complex, data_2order], 2)
# 		data_complex = np.expand_dims(data_complex, axis=1)
# 		data_complex = np.concatenate([np.real(data_complex), np.imag(data_complex)],1)  # shape: sample, 2, 4, 208, 4
# 		data2 = data_complex
# 		self.data = data2

# 	def __getitem__(self, index):
# 		return self.data[index]

# 	def __len__(self):
# 		return self.data.shape[0]

# Number to Bit Function Defining
def Num2Bit(Num, B):
	Num_ = Num.type(torch.uint8)
	def integer2bit(integer, num_bits=B * 2):
		dtype = integer.type()
		exponent_bits = -torch.arange(-(num_bits - 1), 1).type(dtype)
		exponent_bits = exponent_bits.repeat(integer.shape + (1,))
		out = integer.unsqueeze(-1) // 2 ** exponent_bits
		return (out - (out % 1)) % 2
	bit = integer2bit(Num_)
	bit = (bit[:, :, B:]).reshape(-1, Num_.shape[1] * B)
	return bit.type(torch.float32)
def Bit2Num(Bit, B):
	Bit_ = Bit.type(torch.float32)
	Bit_ = torch.reshape(Bit_, [-1, int(Bit_.shape[1] / B), B])
	num = torch.zeros(Bit_[:, :, 1].shape).cuda()
	for i in range(B):
		num = num + Bit_[:, :, i] * 2 ** (B - 1 - i)
	return num
# Quantization and Dequantization Layers Defining
class Quantization(torch.autograd.Function):
	@staticmethod
	def forward(ctx, x, B):
		ctx.constant = B
		step = 2 ** B
		out = torch.round(x * step - 0.5)
		out = Num2Bit(out, B)
		return out
	@staticmethod
	def backward(ctx, grad_output):
		# return as many input gradients as there were arguments.
		# Gradients of constant arguments to forward must be None.
		# Gradient of a number is the sum of its B bits.
		b, _ = grad_output.shape
		grad_num = torch.sum(grad_output.reshape(b, -1, ctx.constant), dim=2) / ctx.constant
		return grad_num, None
class Dequantization(torch.autograd.Function):
	@staticmethod
	def forward(ctx, x, B):
		ctx.constant = B
		step = 2 ** B
		out = Bit2Num(x, B)
		out = (out + 0.5) / step
		return out
	@staticmethod
	def backward(ctx, grad_output):
		# return as many input gradients as there were arguments.
		# Gradients of non-Tensor arguments to forward must be None.
		# repeat the gradient of a Num for B time.
		b, c = grad_output.shape
		grad_output = grad_output.unsqueeze(2) / ctx.constant
		grad_bit = grad_output.expand(b, c, ctx.constant)
		return torch.reshape(grad_bit, (-1, c * ctx.constant)), None
class QuantizationLayer(nn.Module):
	def __init__(self, B):
		super().__init__()
		self.B = B
	def forward(self, x):
		out = Quantization.apply(x, self.B)
		return out
class DequantizationLayer(nn.Module):
	def __init__(self, B):
		super().__init__()
		self.B = B
	def forward(self, x):
		out = Dequantization.apply(x, self.B)
		return out 

class PositionalEncoding(nn.Module):
	def __init__(self, d_model: int, dropout: float = 0.1, max_len: int = 128):
		super().__init__()
		#self.dropout = nn.Dropout(p=dropout)
		position = torch.arange(max_len).unsqueeze(1)
		div_term = torch.exp(torch.arange(0, d_model, 2) * (-math.log(10000.0) / d_model))
		pe = torch.zeros(max_len, 1, d_model)
		pe[:, 0, 0::2] = torch.sin(position * div_term)
		pe[:, 0, 1::2] = torch.cos(position * div_term)
		self.register_buffer('pe', pe)
	def forward(self, x):
		"""
		Args:
			x: Tensor, shape [seq_len, batch_size, embedding_dim]
		"""
		x = x + self.pe[:x.size(0)]
		return x

class FeedForward(nn.Module):
	def __init__(self, dim, hidden_dim, dropout = 0., csi=False):
		super().__init__()
		if csi:
			self.net = nn.Sequential(
			nn.LayerNorm(dim),
			nn.Linear(dim, hidden_dim),
			nn.GELU(),
			nn.Linear(hidden_dim, dim),
			)
		else:
			self.net = nn.Sequential(
				nn.Linear(dim, hidden_dim),
				nn.GELU(),
				nn.Dropout(dropout),
				nn.Linear(hidden_dim, dim),
				nn.Dropout(dropout)
			)
		
	def forward(self, x):
		return self.net(x)


class Attention(nn.Module):
	def __init__(self, dim, heads = 8, dim_head = 64):
		super().__init__()
		inner_dim = dim_head *  heads
		self.heads = heads
		self.scale = dim_head ** -0.5
		self.norm = nn.LayerNorm(dim)

		self.attend = nn.Softmax(dim = -1)

		self.to_qkv = nn.Linear(dim, inner_dim * 3, bias = False)
		self.to_out = nn.Linear(inner_dim, dim, bias = False)

	def forward(self, x):
		x = self.norm(x)

		qkv = self.to_qkv(x).chunk(3, dim = -1)
		q, k, v = map(lambda t: rearrange(t, 'b n (h d) -> b h n d', h = self.heads), qkv)

		dots = torch.matmul(q, k.transpose(-1, -2)) * self.scale

		attn = self.attend(dots)

		out = torch.matmul(attn, v)
		out = rearrange(out, 'b h n d -> b n (h d)')
		return self.to_out(out)


class MDBlockS(nn.Module):
	def __init__(self, dim, num_patch, token_dim, channel_dim, dropout = 0., h =0, w=0):
		super().__init__()
		self.channel_mix = nn.Sequential(
			nn.LayerNorm(dim),
			FeedForward(dim, channel_dim, dropout),
		)
		self.w_mix = nn.Sequential(
			nn.LayerNorm(dim),
			Rearrange('b (h w) d -> b d h w', h=h),
			FeedForward(w, token_dim, dropout),
			Rearrange('b d h w -> b (h w) d', h=h),
		)
		self.h_mix = nn.Sequential(
			nn.LayerNorm(dim),
			Rearrange('b (h w) d -> b d w h', h=h),
			FeedForward(h, token_dim, dropout),
			Rearrange('b d w h -> b (h w) d', h=h),
		)

	def forward(self, x):
		x = x + self.w_mix(x)
		x = x + self.h_mix(x)
		x = x + self.channel_mix(x)
		return x

class MLPMDS(nn.Module):
	def __init__(self, in_channels=8, dim=192, num_output=8, patch_size_h=1, patch_size_w=2, image_size_h=32, image_size_w=52, depth=3, token_dim=256, channel_dim=256):
		super().__init__()
		assert image_size_w % patch_size_w == 0, 'Image dimensions must be divisible by the patch size.'
		assert image_size_h % patch_size_h == 0, 'Image dimensions must be divisible by the patch size.'
		self.num_patch =  (image_size_h// patch_size_h) * (image_size_w// patch_size_w)
		self.to_patch_embedding = nn.Sequential(
			nn.Conv2d(in_channels, dim, (patch_size_h, patch_size_w), (patch_size_h, patch_size_w)),
			Rearrange('b c h w -> b (h w) c'),
		)
		self.mixer_blocks = nn.ModuleList([])
		for _ in range(depth):
			self.mixer_blocks.append(MDBlockS(dim, self.num_patch, token_dim, channel_dim, dropout = 0., h =image_size_h,w=image_size_w//patch_size_w))
		self.layer_norm = nn.LayerNorm(dim)
		self.mlp_head = nn.Sequential(
			nn.Linear(dim, num_output)
		)
	def forward(self, x): # (batch, 8, 26, 32)
		x = self.to_patch_embedding(x) # (batch, patch, dim)
		for mixer_block in self.mixer_blocks:
			x = mixer_block(x)
		x = self.layer_norm(x) # (batch, patch, dim)
		#x = x.mean(dim=1)
		return self.mlp_head(x) 

class MDMLPS(nn.Module):
	def __init__(self, input_length=208, channel_dim=256):
		super(MDMLPS, self).__init__()
		pilot_num = int(input_length / 8)
		emd_dim = 192
		out_dim = 8
		patch_size_h=1
		patch_size_w=2
		image_size_h=32
		image_size_w=52
		num_patch =  (image_size_h// patch_size_h) * (image_size_w// patch_size_w)
		self.mlp_mixer = MLPMDS(in_channels=8, dim=emd_dim, num_output=out_dim, 
								patch_size_h=patch_size_h, patch_size_w=patch_size_w, image_size_h=image_size_h, image_size_w=image_size_w, depth=3, token_dim=256, channel_dim=256)
		self.fc1 = nn.Linear(pilot_num, image_size_w)
		self.fc2 = nn.Linear(num_patch, image_size_h*image_size_w)
	
	def forward(self, x): #(batch, 2, 4, 208 or 48, 4)
		x = rearrange(x, 'b c rx (rb subc) sym -> b (c rx) (subc sym) rb', subc=8) # (batch,8,32,26 or 6)
		x = self.fc1(x) # (batch,8,32,52)
		out = self.mlp_mixer(x) # (batch, patch_num, out_dim)
		out = rearrange(out, 'b p o -> b o p')
		out = self.fc2(out) # (batch, 8, 52*32)
		out = rearrange(out, 'b (c rx) (tx rb) -> b c rx tx rb', rx=4, tx=32)
		return out

class PositionalEncodingBits(nn.Module):
	def __init__(self, d_model: int, dropout: float = 0.1, max_len: int = 128):
		super().__init__()
		#self.dropout = nn.Dropout(p=dropout)
		position = torch.arange(max_len).unsqueeze(1)
		div_term = torch.exp(torch.arange(0, d_model, 2) * (-math.log(10000.0) / d_model))
		pe = torch.zeros(max_len, d_model)
		pe[:, 0::2] = torch.sin(position * div_term)
		pe[:, 1::2] = torch.cos(position * div_term)
		self.pe = pe.cuda()
	def forward(self, x):
		"""
		Args:
			x: Tensor, shape [seq_len, batch_size, embedding_dim]
		"""
		x = x + self.pe[1:x.size(1)+1].squeeze().unsqueeze(0)
		return x

def pair(t):
	return t if isinstance(t, tuple) else (t, t)


class Transformer(nn.Module):
	def __init__(self, dim, depth, heads, dim_head, mlp_dim,dropout=0.0):
		super().__init__()
		self.layers = nn.ModuleList([])
		for _ in range(depth):
			self.layers.append(nn.ModuleList([
				Attention(dim, heads = heads, dim_head = dim_head),
				FeedForward(dim, mlp_dim,csi=True)
			]))
	def forward(self, x):
		for attn, ff in self.layers:
			x = attn(x) + x
			x = ff(x) + x
		return x

class SimpleViT(nn.Module):
	def __init__(self, dim, depth, heads=4, mlp_dim=2048, in_channels = 2, dim_head = 64, dropout=0.0, arrange = False):
		super().__init__()
		self.to_patch_embedding = nn.Sequential(
			nn.Conv2d(in_channels, dim, (6, 6), (3, 3)),
			Rearrange('b c h w -> (h w) b c'),
			nn.Linear(dim, dim),
		)
		self.pos_encoder = PositionalEncoding(dim, 0.0)
		self.transformer = Transformer(dim, depth, heads, dim_head, mlp_dim, dropout=dropout)
		self.arrange = arrange

	def forward(self, img):
		if self.arrange:
			img = rearrange(img, 'b c (x y h) w ->b c (x h y) w', x=2, y=2)
		
		x = self.to_patch_embedding(img)
		x = self.pos_encoder(x)
		x = rearrange(x, 'n b c -> b n c')
		x = self.transformer(x)
		return x
class Encoder(nn.Module):
	B = 2
	def __init__(self, feedback_bits, quantization=True,d_model=384,nhead=3,d_hid=384,dropout=0.0,nlayers=6, balance_sig=False, quantization_type='org', batch_first=False, tau=0.2, tta=True, tta_num=20, inference=False, gumbel_noise=1.0, arrange=False):
		super(Encoder, self).__init__()
		self.transformer_encoder = SimpleViT(dim=d_model, depth=nlayers, heads=nhead, mlp_dim=d_hid, in_channels = 2, dim_head = d_model//nhead, dropout=dropout, arrange=arrange)
		self.fc1 = nn.Linear(64, d_model)
		self.balance_sig = balance_sig
		self.batch_first = batch_first
		if balance_sig:
			self.fc_b = nn.Linear(27*d_model, int(feedback_bits))
		else:
			self.fc2 = nn.Linear(27*d_model, int(feedback_bits / self.B))
			self.sig = nn.Sigmoid()
		self.quantization = quantization
		self.tau = tau
		self.tta = tta
		self.tta_num = tta_num
		self.inference = inference
		self.gumbel_noise = gumbel_noise
	
	def set_inference(self, flag=False):
		self.inference = flag
	
	def forward(self, x): # (batch, 2, 32, 13), b c eig f
		out = self.transformer_encoder(x)
		out = rearrange(out, 'b n f -> b (n f)')
		if self.balance_sig:
			out = self.fc_b(out)
			if self.tta:
				simple_way = False
				plus_way = True
				if simple_way:
					# simple way
					out = torch.stack([gumbel_sigmoid(out,hard = self.inference, tau=self.tau) for x in range(1,self.tta_num+1)]).cuda()
					# out = out.transpose(0,1).contiguous()
					# reduce repeatted bits:
				elif plus_way: # B*64
					out = gumbel_sigmoid(out.unsqueeze(0).repeat(3000,1,1).view(-1,64), hard = self.inference, tau=self.tau).cuda()
					out = out.view(3000,-1,64)
					_, bs, _ = out.shape
					out_arr = torch.zeros(self.tta_num,bs,64)
					for idx in range(0,bs):
						u_out = torch.unique(out[:,idx,:],dim=0, sorted=True)
						lenout = u_out.shape[0]
						if lenout<self.tta_num:
							# uout = torch.stack([u_out,u_out[]]).view(-1,64)
							index = torch.arange(0,lenout).long().cuda()
							index_others = torch.rand(self.tta_num - lenout)*(lenout-1)
							index_others = index_others.long().cuda()
							a = torch.index_select(u_out,0, index)
							b = torch.index_select(u_out,0, index_others)
							u_out = torch.cat([a,b],dim=0)
							out_arr[:,idx,:] = u_out
						else:
							out_arr[:,idx,:] = u_out[:self.tta_num,:]	
					out = out_arr
				else:
					# for each batch, generates N unique samples for TTA
					out = torch.stack([gumbel_sigmoid(out,hard = self.inference, tau=self.tau) for x in range(1,4096)]).cuda()
					_, bs, _ = out.shape
					out_arr = torch.zeros(self.tta_num,bs,64)
					for idx in range(0,bs):
						u_out = torch.unique(out[:,idx,:],dim=0, sorted=True)
						lenout = u_out.shape[0]
						if lenout<self.tta_num:
							# uout = torch.stack([u_out,u_out[]]).view(-1,64)
							index = torch.arange(0,lenout).long().cuda()
							index_others = torch.rand(self.tta_num - lenout)*(lenout-1)
							index_others = index_others.long().cuda()
							a = torch.index_select(u_out,0, index)
							b = torch.index_select(u_out,0, index_others)
							u_out = torch.cat([a,b],dim=0)
							out_arr[:,idx,:] = u_out
						else:
							out_arr[:,idx,:] = u_out[:self.tta_num,:]
						
					# out = torch.stack([idx for idx in range(0,bs-1)])
					out = out_arr
				out = out.view(-1,64).cuda()
			else:
				out = gumbel_sigmoid(out,hard = self.inference, tau=self.tau, gumbel_noise = self.gumbel_noise)
			# out = hardisg(out,lamda=10.0)
			# out = out[:,:32]*(2.0/3.0) + out[:,32:]*(1.0/3.0)
		else:
			out = self.fc2(out) # (batch, 512/B)
			out = self.sig(out)

		return out
	
class Decoder(nn.Module):
	B = 2
	def __init__(self, feedback_bits, quantization=True,d_model=384,nhead=3,d_hid=384,dropout=0.0,nlayers=6, 
				balance_sig=False, quantization_type='org', batch_first=False, cnn=False, codeformer = False):
		super(Decoder, self).__init__()
		self.pos_encoder = PositionalEncoding(d_model, dropout)
		self.pos_encoder_bits = PositionalEncodingBits(1)
		decoder_layers = nn.TransformerEncoderLayer(d_model, nhead, d_hid, dropout)
		self.transformer_decoder = nn.TransformerEncoder(decoder_layers, nlayers)
		# self.sig = nn.Sigmoid()
		self.quantization = quantization 
		self.feedback_bits = feedback_bits
		self.batch_first = batch_first
		self.balance_sig = balance_sig
		if quantization_type !='org':
			self.dequantize = DequantizationLayer(self.B)
		else:
			self.dequantize = DequantizationLayer(self.B)
		if balance_sig: #B, bit
			# self.conv_fuse = nn.Sequential(
			# 		nn.Conv1d(1, 512, kernel_size=3, stride=1, padding=1, bias=True),
			# 		nn.Conv1d(512, 1, kernel_size=3, stride=1, padding=1, bias=True))
			self.fc_b = nn.Linear(int(feedback_bits), 13*d_model)
		else:
			self.fc1 = nn.Linear(int(feedback_bits / self.B), 13*d_model)
		self.fc2 = nn.Linear(d_model, 32*2)
	def forward(self, x):
		out = x
		if self.balance_sig:
			out = self.pos_encoder_bits(out)
			# out = self.conv_fuse(out.unsqueeze(1)).squeeze(1)
			out = self.fc_b(out)
		else:
			out = self.fc1(out) # (batch, 13*d_model)
		out = rearrange(out, 'b (f dmodel) -> f b dmodel', f=13)
		out = self.pos_encoder(out)
		if self.batch_first:
			out = rearrange(out, 's b f -> b s f', s=13)
		out = self.transformer_decoder(out) # (13, batch, d_model)
		if self.batch_first:
			out = rearrange(out, 'b s f -> s b f', s=13)
		out = self.fc2(out) # (13, batch, 32*2)
		out = rearrange(out, 'f b (c eig) -> b c eig f', c=2)
		return out

class VITAE(nn.Module):
	def __init__(self, feedback_bits,quantization=True,d_model=384,nhead=3,d_hid=384,dropout=0.0,en_nlayers=6, de_nlayers=6, LN=False, balance_sig=False, 
			quantization_type='org', batch_first=False,tau=0.2,tta=True, tta_num=20, inference=False, cnn=False, codeformer = False, gumbel_noise=1.0, arrange=False):
		super(VITAE, self).__init__()
		self.encoder = Encoder(feedback_bits,quantization, d_model, nhead, d_hid, dropout, en_nlayers, balance_sig, quantization_type=quantization_type, batch_first=batch_first,tau=tau,tta=tta,tta_num = tta_num, inference=inference, arrange=arrange)
		self.decoder = Decoder(feedback_bits,quantization, d_model, nhead, d_hid, dropout, de_nlayers, balance_sig, quantization_type=quantization_type, batch_first=batch_first, cnn=cnn, codeformer = codeformer)
		self.LN = LN
		self.tta = tta
		self.tta_num = tta_num
		# self.apply(self._init_weights)
		# if self.LN:
		# 	self.inln = torch.nn.Sequential(
		# 		Rearrange('b c h w -> b c w h'),
		# 		torch.nn.LayerNorm((32), elementwise_affine=False),
		# 		Rearrange('b c w h -> b c h w')
		# 		)
		# else:
		# 	self.inln = lambda x: x  # identity

	def norminput(self,x):
		x = x.permute(0, 3, 2, 1)
		bs, sc, ant, _ = x.shape
		x = x.reshape(bs*sc, ant, 2)
		x_re, x_im = x[..., 0], x[..., 1]
		# p = torch.sqrt((x_re ** 2 + x_im ** 2).sum(-1)).unsqueeze(1).unsqueeze(1)
		v,_ = torch.max(x.view(bs*sc,-1),dim=1)
		v = v.unsqueeze(1).unsqueeze(1)
		x /= v
		x = x.view(bs, sc, ant, 2).permute(0, 3, 2, 1)

		return x
			
	def set_inference(self, flag=False):
		self.encoder.set_inference(flag = flag)

	def cal_cossim(self,w_true,w_pre):
		eps = 1e-20
		w_true, w_pre = w_true.permute(0, 3, 2, 1), w_pre.permute(0, 3, 2, 1)
		num_batch, num_sc, num_ant = w_true.size(0), w_true.size(1), w_true.size(2)
		w_true = w_true.reshape(num_batch * num_sc, num_ant, 2)
		w_pre = w_pre.reshape(num_batch * num_sc, num_ant, 2)
		w_true_re, w_true_im = w_true[..., 0], w_true[..., 1]
		w_pre_re, w_pre_im = w_pre[..., 0], w_pre[..., 1]
		numerator_re = (w_true_re * w_pre_re + w_true_im * w_pre_im).sum(-1)
		numerator_im = (w_true_im * w_pre_re - w_true_re * w_pre_im).sum(-1)
		denominator_0 = (w_true_re ** 2 + w_true_im ** 2).sum(-1)
		denominator_1 = (w_pre_re ** 2 + w_pre_im ** 2).sum(-1)
		cos_similarity = torch.sqrt(numerator_re ** 2 + numerator_im ** 2) / (
					torch.sqrt(denominator_0) * torch.sqrt(denominator_1)+eps)
		cos_similarity = cos_similarity ** 2
		cos_similarity = cos_similarity.view(num_batch,num_sc).mean(1)
		return cos_similarity

	def enc_forward(self, x):
		# if self.LN:
		# 	x = self.inln(x)
		BS = x.shape[0]
		if self.LN:
			x = self.norminput(x)
		feature = self.encoder(x)
		if self.tta:
			with torch.no_grad():
				out = self.decoder(feature)
				score = self.cal_cossim(torch.stack([x for _ in range(1,self.tta_num+1)]).cuda().view(out.shape),out).view(self.tta_num,-1)
				best_idx = score.argmax(0)
				best_idx_2 = torch.arange(0,BS).long().cuda()
				feature = feature.view(self.tta_num,-1, 64)[best_idx,best_idx_2,:]
		return feature
	
	def dec_forward(self, x):	
		x = self.decoder(x)
		if self.LN:
			x = torch.tanh(x)
		return x


class MixerBlock(nn.Module):
	def __init__(self, dim, num_patch, token_dim, channel_dim, dropout = 0.):
		super().__init__()
		self.token_mix = nn.Sequential(
			nn.LayerNorm(dim),
			Rearrange('b n d -> b d n'),
			FeedForward(num_patch, token_dim, dropout),
			Rearrange('b d n -> b n d')
		)
		self.channel_mix = nn.Sequential(
			nn.LayerNorm(dim),
			FeedForward(dim, channel_dim, dropout),
		)

	def forward(self, x):
		x = x + self.token_mix(x)
		x = x + self.channel_mix(x)
		return x


class MLPMixer(nn.Module):
	def __init__(self, in_channels=8, dim=192, num_output=8, patch_size_h=1, patch_size_w=2, image_size_h=32, image_size_w=52, depth=3, token_dim=256, channel_dim=256):
		super().__init__()
		assert image_size_w % patch_size_w == 0, 'Image dimensions must be divisible by the patch size.'
		assert image_size_h % patch_size_h == 0, 'Image dimensions must be divisible by the patch size.'
		self.num_patch =  (image_size_h// patch_size_h) * (image_size_w// patch_size_w)
		self.to_patch_embedding = nn.Sequential(
			nn.Conv2d(in_channels, dim, (patch_size_h, patch_size_w), (patch_size_h, patch_size_w)),
			Rearrange('b c h w -> b (h w) c'),
		)
		self.mixer_blocks = nn.ModuleList([])
		for _ in range(depth):
			self.mixer_blocks.append(MixerBlock(dim, self.num_patch, token_dim, channel_dim))
		self.layer_norm = nn.LayerNorm(dim)
		self.mlp_head = nn.Sequential(
			nn.Linear(dim, num_output)
		)
	def forward(self, x): # (batch, 8, 26, 32)
		x = self.to_patch_embedding(x) # (batch, patch, dim)
		for mixer_block in self.mixer_blocks:
			x = mixer_block(x)
		x = self.layer_norm(x) # (batch, patch, dim)
		#x = x.mean(dim=1)
		return self.mlp_head(x) 


class MIX(nn.Module):
	def __init__(self, input_length=208, channel_dim=256):
		super(MIX, self).__init__()
		pilot_num = int(input_length / 8)
		emd_dim = 192
		out_dim = 8
		patch_size_h=1
		patch_size_w=2
		image_size_h=32
		image_size_w=52
		num_patch =  (image_size_h// patch_size_h) * (image_size_w// patch_size_w)
		self.mlp_mixer = MLPMixer(in_channels=8, dim=emd_dim, num_output=out_dim, 
								patch_size_h=patch_size_h, patch_size_w=patch_size_w, image_size_h=image_size_h, image_size_w=image_size_w, depth=3, token_dim=256, channel_dim=channel_dim)
		self.fc1 = nn.Linear(pilot_num, image_size_w)
		self.fc2 = nn.Linear(num_patch, image_size_h*image_size_w)
	
	def forward(self, x): #(batch, 2, 4, 208 or 48, 4)
		x = rearrange(x, 'b c rx (rb subc) sym -> b (c rx) (subc sym) rb', subc=8) # (batch,8,32,26 or 6)
		x = self.fc1(x) # (batch,8,32,52)
		out = self.mlp_mixer(x) # (batch, patch_num, out_dim)
		out = rearrange(out, 'b p o -> b o p')
		out = self.fc2(out) # (batch, 8, 52*32)
		out = rearrange(out, 'b (c rx) (tx rb) -> b c rx tx rb', rx=4, tx=32)
		return out

class ModelBuilder(nn.Module):
	def __init__(self, input_length=208, channel_dim=256, feedback_bits=64,d_model=384,nhead=3,d_hid=384,dropout=0.0,en_nlayers=6, de_nlayers=6, LN=False, balance_sig=False, tau=0.2,tta=True, tta_num=20,cest=True, csi=True, arrange=False):
		super(ModelBuilder, self).__init__()
		# build backbone
		if cest:
			self.cest = MDMLPS(input_length=input_length, channel_dim=channel_dim)
			# self.cest = MIX(input_length=input_length, channel_dim=channel_dim)
		if csi:
			self.csi = VITAE(feedback_bits=feedback_bits,d_model=d_model,
				nhead=nhead,d_hid=d_hid,dropout=0.0,en_nlayers=en_nlayers, de_nlayers=de_nlayers,
				LN=LN, balance_sig=balance_sig,
				tau=tau,tta=tta, tta_num=tta_num,  arrange=arrange)
			self.csi.set_inference(True)
	def forward(self, pilot):
		return self.cest(pilot.cuda())


#=======================================================================================================================
#=======================================================================================================================
# Data Loader Class Defining
class DatasetFolder(Dataset):
	def __init__(self, matInput, matLabel):
		self.input, self.label = matInput, matLabel
	def __getitem__(self, index):
		return self.input[index], self.label[index]
	def __len__(self):
		return self.input.shape[0]
class DatasetFolder_eval(Dataset):
	def __init__(self, data):
		self.data = data
	def __getitem__(self, index):
		return self.data[index]
	def __len__(self):
		return self.data.shape[0]
	
def cal_eigenvector(channel):
	"""
		Description:
			calculate the eigenvector on each subband
		Input:
			channel: np.array, channel in frequency domain,  shape [batch_size, rx_num, tx_num, subcarrier_num]
		Output:
			eigenvectors:  np.array, eigenvector for each subband, shape [batch_size, tx_num, subband_num]
	"""
	subband_num = 13
	hf_ = np.transpose(channel, [0,3,1,2]) # (batch,subcarrier_num,4,32)
	hf_h = np.conj(np.transpose(channel, [0,3,2,1])) # (batch,subcarrier_num,32,4)
	R = np.matmul(hf_h, hf_) # (batch,subcarrier_num,32,32)
	R = R.reshape(R.shape[0],subband_num,-1,R.shape[2],R.shape[3]).mean(axis=2) # average the R over each subband, (batch,13,32,32)
	[D,V] = np.linalg.eig(R)
	v = V[:,:,:,0]
	eigenvectors = np.transpose(v,[0,2,1])
	return eigenvectors

def gene_higher_pilot(data):
	data_complex = data[:, 0, ...] + 1j * data[:, 1, ...]
	data_2order = data_complex * (np.abs(data_complex) ** 2)
	data_complex = np.concatenate([data_complex, data_2order], 2)
	data_complex = np.expand_dims(data_complex, axis=1)
	data_complex = np.concatenate([np.real(data_complex), np.imag(data_complex)], 1)  # shape: sample, 2, 4, 208, 4
	return data_complex

# class DatasetFolder_cest(Dataset):
# 	def __init__(self, data):
# 		self.data = data
# 	def __getitem__(self, index):
# 		return self.data[index]
# 	def __len__(self):
# 		return self.data.shape[0]
	

#=======================================================================================================================
#=======================================================================================================================
# Function Defining
def encFunction_1(pilot_1, encModel_p1_1_path, encModel_p1_2_path):
	"""
		Description:
			CSI compression based on received pilot signal
		Input:
			pilot_1: np.array, received pilot signal,  shape [NUM_SAMPLES, 2, rx_num, pilot on different subcarrier, pilot on different symbol]
			encModel_p1_1_path: path to load the first AI model, please ignore if not needed
			encModel_p1_2_path: path to load the second AI model, please ignore if not needed
			*** Note: Participants can flexibly decide to use 0/1/2 AI model in this function, needless model path can be ignored
		Output:
			output_all:  np.array, encoded bit steam, shape [NUM_SAMPLES, NUM_FEEDBACK_BITS]
	"""
	seed_torch(123456)
	model = ModelBuilder(input_length=416, channel_dim=256, feedback_bits=64,d_model=384,
						nhead=4,d_hid=1024,en_nlayers=4, de_nlayers=4,balance_sig=True, 
						LN=False, tau=0.2,tta=True, tta_num=300, arrange=True).cuda().eval()
	
	model.load_state_dict(torch.load(encModel_p1_1_path)['state_dict'],strict=False)
	# pilot_1 = gene_higher_pilot(pilot_1)
	test_dataset = DatasetFolder_eval(pilot_1)
	test_loader = torch.utils.data.DataLoader(test_dataset, batch_size=200, shuffle=False, num_workers=4, pin_memory=True)
	with torch.no_grad():
		for idx, data in enumerate(test_loader):
			data = torch.tensor(gene_higher_pilot(data.numpy()))
			data = data.cuda()
			# step 1: channel estimation
			h = model.cest(data) # (batch,2,4,32,52)
			# step 2: eigenvector calculation
			h_complex = h[:,0,...] + 1j*h[:,1,...] # (batch,4,32,52)
			h_complex = h_complex.cpu().numpy()
			v = cal_eigenvector(h_complex)
			# step 3: eigenvector compression
			w_complex = torch.from_numpy(v)
			w = torch.zeros([h.shape[0], 2, 32, 13], dtype=torch.float32).cuda() # (batch,2,32,13)
			w[:,0,:,:] = torch.real(w_complex)
			w[:,1,:,:] = torch.imag(w_complex)
			modelOutput = model.csi.enc_forward(w)
			modelOutput = modelOutput.cpu().numpy()
			if idx == 0:
				output_all = modelOutput
			else:
				output_all = np.concatenate((output_all, modelOutput), axis=0)
	return output_all

def encFunction_2(pilot_2, encModel_p2_1_path, encModel_p2_2_path):
	model = ModelBuilder(input_length=96, channel_dim=256, feedback_bits=64,d_model=384,
						nhead=4,d_hid=1024,en_nlayers=4, de_nlayers=4,balance_sig=True, 
						LN=False, tau=0.2,tta=True, tta_num=300, arrange=True).cuda().eval()
	model.load_state_dict(torch.load(encModel_p2_1_path)['state_dict'],strict=False)
	# pilot_2 = gene_higher_pilot(pilot_2)
	test_dataset = DatasetFolder_eval(pilot_2)
	# test_dataset = DatasetFolder_higher_eval(pilot_2)
	test_loader = torch.utils.data.DataLoader(test_dataset, batch_size=200, shuffle=False, num_workers=4, pin_memory=True)
	with torch.no_grad():
		for idx, data in enumerate(test_loader):
			data = torch.tensor(gene_higher_pilot(data.numpy()))
			data = data.cuda()
			# step 1: channel estimation
			h = model.cest(data) # (batch,2,4,32,52)
			# step 2: eigenvector calculation
			h_complex = h[:,0,...] + 1j*h[:,1,...] # (batch,4,32,52)
			h_complex = h_complex.cpu().numpy()
			v = cal_eigenvector(h_complex)
			# step 3: eigenvector compression
			w_complex = torch.from_numpy(v)
			w = torch.zeros([h.shape[0], 2, 32, 13], dtype=torch.float32).cuda() # (batch,2,32,13)
			w[:,0,:,:] = torch.real(w_complex)
			w[:,1,:,:] = torch.imag(w_complex)
			modelOutput = model.csi.enc_forward(w)
			modelOutput = modelOutput.cpu().numpy()
			if idx == 0:
				output_all = modelOutput
			else:
				output_all = np.concatenate((output_all, modelOutput), axis=0)
	return output_all

def decFunction_1(bits_1, decModel_p1_1_path, decModel_p1_2_path):
	"""
		Description:
			CSI reconstruction based on feedbacked bit stream
		Input:
			bits_1: np.array, feedbacked bit stream,  shape [NUM_SAMPLES, NUM_FEEDBACK_BITS]
			decModel_p1_1_path: path to load the first AI model, please ignore if not needed
			decModel_p1_2_path: path to load the second AI model, please ignore if not needed
			*** Note: Participants can flexibly decide to use 0/1/2 AI model in this function, needless model path can be ignored
		Output:
			output_all:  np.array, reconstructed CSI (eigenvectors), shape [NUM_SAMPLES, 2, NUM_TX, NUM_SUBBAND]
	"""
	model = ModelBuilder(input_length=416, channel_dim=256, feedback_bits=64,d_model=384,
						nhead=4,d_hid=1024,en_nlayers=4, de_nlayers=4,balance_sig=True, 
						LN=False, tau=0.2,tta=True, tta_num=300,cest=False, arrange=True ).cuda().eval()
	model.load_state_dict(torch.load(decModel_p1_1_path)['state_dict'],strict=False)
	test_dataset = DatasetFolder_eval(bits_1)
	test_loader = torch.utils.data.DataLoader(test_dataset, batch_size=200, shuffle=False, num_workers=4, pin_memory=True)
	model.eval()
	with torch.no_grad():
		for idx, data in enumerate(test_loader):
			data = data.cuda()
			modelOutput = model.csi.dec_forward(data)
			modelOutput = modelOutput.cpu().numpy()
			if idx == 0:
				output_all = modelOutput
			else:
				output_all = np.concatenate((output_all, modelOutput), axis=0)
	return output_all

def decFunction_2(bits_2, decModel_p2_1_path, decModel_p2_2_path):
	"""
		Description:
			CSI reconstruction based on feedbacked bit stream
		Input:
			bits_1: np.array, feedbacked bit stream,  shape [NUM_SAMPLES, NUM_FEEDBACK_BITS]
			decModel_p1_1_path: path to load the first AI model, please ignore if not needed
			decModel_p1_2_path: path to load the second AI model, please ignore if not needed
			*** Note: Participants can flexibly decide to use 0/1/2 AI model in this function, needless model path can be ignored
		Output:
			output_all:  np.array, reconstructed CSI (eigenvectors), shape [NUM_SAMPLES, 2, NUM_TX, NUM_SUBBAND]
	"""
	model = ModelBuilder(input_length=96, channel_dim=256, feedback_bits=64,d_model=384,
						nhead=4,d_hid=1024,en_nlayers=4, de_nlayers=4,balance_sig=True, 
						LN=False, tau=0.2,tta=True, tta_num=300, cest=False, arrange=True).cuda().eval()	
	model.load_state_dict(torch.load(decModel_p2_1_path)['state_dict'],strict=False)
	test_dataset = DatasetFolder_eval(bits_2)
	test_loader = torch.utils.data.DataLoader(test_dataset, batch_size=200, shuffle=False, num_workers=4, pin_memory=True)
	model.eval()
	with torch.no_grad():
		for idx, data in enumerate(test_loader):
			data = data.cuda()
			modelOutput = model.csi.dec_forward(data)
			modelOutput = modelOutput.cpu().numpy()
			if idx == 0:
				output_all = modelOutput
			else:
				output_all = np.concatenate((output_all, modelOutput), axis=0)
	return output_all

def encFunction_1_gene(pilot_1, encModel_p1_1_path, encModel_p1_2_path):
	"""
		Description:
			CSI compression based on received pilot signal
		Input:
			pilot_1: np.array, received pilot signal,  shape [NUM_SAMPLES, 2, rx_num, pilot on different subcarrier, pilot on different symbol]
			encModel_p1_1_path: path to load the first AI model, please ignore if not needed
			encModel_p1_2_path: path to load the second AI model, please ignore if not needed
			*** Note: Participants can flexibly decide to use 0/1/2 AI model in this function, needless model path can be ignored
		Output:
			output_all:  np.array, encoded bit steam, shape [NUM_SAMPLES, NUM_FEEDBACK_BITS]
	"""
	seed_torch(123456)
	model = ModelBuilder(input_length=416, channel_dim=256, feedback_bits=64,d_model=384,
						nhead=4,d_hid=1024,en_nlayers=4, de_nlayers=4,balance_sig=True, 
						LN=False, tau=0.2,tta=True, tta_num=300, arrange=True).cuda().eval()
	
	model.load_state_dict(torch.load(encModel_p1_1_path)['state_dict'],strict=False)
	# pilot_1 = gene_higher_pilot(pilot_1)
	test_dataset = DatasetFolder_eval(pilot_1)
	test_loader = torch.utils.data.DataLoader(test_dataset, batch_size=200, shuffle=False, num_workers=4, pin_memory=True)
	with torch.no_grad():
		for idx, data in enumerate(test_loader):
			data = torch.tensor(gene_higher_pilot(data.numpy()))
			data = data.cuda()
			# step 1: channel estimation
			h = model.cest(data) # (batch,2,4,32,52)
			# step 2: eigenvector calculation
			h_complex = h[:,0,...] + 1j*h[:,1,...] # (batch,4,32,52)
			h_complex = h_complex.cpu().numpy()
			v = cal_eigenvector(h_complex)
			# step 3: eigenvector compression
			w_complex = torch.from_numpy(v)
			w = torch.zeros([h.shape[0], 2, 32, 13], dtype=torch.float32).cuda() # (batch,2,32,13)
			w[:,0,:,:] = torch.real(w_complex)
			w[:,1,:,:] = torch.imag(w_complex)
			modelOutput = w.cpu().numpy()
			if idx == 0:
				output_all = modelOutput
			else:
				output_all = np.concatenate((output_all, modelOutput), axis=0)
	return output_all

def encFunction_2_gene(pilot_2, encModel_p2_1_path, encModel_p2_2_path):
	model = ModelBuilder(input_length=96, channel_dim=256, feedback_bits=64,d_model=384,
						nhead=4,d_hid=1024,en_nlayers=4, de_nlayers=4,balance_sig=True, 
						LN=False, tau=0.2,tta=True, tta_num=300, arrange=True).cuda().eval()
	model.load_state_dict(torch.load(encModel_p2_1_path)['state_dict'],strict=False)
	# pilot_2 = gene_higher_pilot(pilot_2)
	test_dataset = DatasetFolder_eval(pilot_2)
	# test_dataset = DatasetFolder_higher_eval(pilot_2)
	test_loader = torch.utils.data.DataLoader(test_dataset, batch_size=200, shuffle=False, num_workers=4, pin_memory=True)
	with torch.no_grad():
		for idx, data in enumerate(test_loader):
			data = torch.tensor(gene_higher_pilot(data.numpy()))
			data = data.cuda()
			# step 1: channel estimation
			h = model.cest(data) # (batch,2,4,32,52)
			# step 2: eigenvector calculation
			h_complex = h[:,0,...] + 1j*h[:,1,...] # (batch,4,32,52)
			h_complex = h_complex.cpu().numpy()
			v = cal_eigenvector(h_complex)
			# step 3: eigenvector compression
			w_complex = torch.from_numpy(v)
			w = torch.zeros([h.shape[0], 2, 32, 13], dtype=torch.float32).cuda() # (batch,2,32,13)
			w[:,0,:,:] = torch.real(w_complex)
			w[:,1,:,:] = torch.imag(w_complex)
			modelOutput = w.cpu().numpy()
			if idx == 0:
				output_all = modelOutput
			else:
				output_all = np.concatenate((output_all, modelOutput), axis=0)
	return output_all