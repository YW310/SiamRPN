# source ~/.bashrc
# cd /data/project/transwaic_c/exp/dec/
echo 'start s0 training stage'
python -m torch.distributed.launch --nproc_per_node=4 --master_port=2337 ../../train.py --config 'config_s0.yaml'
echo 'start s1 training stage'
python -m torch.distributed.launch --nproc_per_node=4 --master_port=2337 ../../train.py --config 'config_s1.yaml'
echo 'start s2 training stage'
python -m torch.distributed.launch --nproc_per_node=4 --master_port=2337 ../../train.py --config 'config_s2.yaml'