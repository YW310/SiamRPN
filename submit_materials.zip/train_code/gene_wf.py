#=======================================================================================================================
#=======================================================================================================================
# Package Importing
import sys
import numpy as np
import torch
from torch import nn
from torch.utils.data import Dataset
import tqdm
# from utils.config import cfg
import random
import os
#=======================================================================================================================
#=======================================================================================================================
# Eigenvector Calculation Function Defining
#=======================================================================================================================
#=======================================================================================================================
# Package Importing
import sys
import os
import numpy as np
from submit.modelDesign import encFunction_1_gene, encFunction_2_gene
#=======================================================================================================================
#=======================================================================================================================
# Parameters Setting
NUM_SAMPLES = 6000
NUM_FEEDBACK_BITS = 64
NUM_RX = 4
NUM_TX = 32
NUM_SUBBAND = 13
#=======================================================================================================================
#=======================================================================================================================
# Data Loading
# Data 1 Loading
pilot_1 = np.load('Data/pilot_1.npz')['data']
# length = pilot_1.shape[0]
# split_idx = int(0.98 * length)
# pilot_1 = pilot_1[split_idx:,...]
pilot_1 = np.expand_dims(pilot_1, axis=1)
pilot_1 = np.concatenate([np.real(pilot_1), np.imag(pilot_1)], 1) # shape: sample, 2, 4, 208, 4
w_1 =  np.load('Data/w.npz')['data']
# w_1 = w_1[split_idx:,...]
w_1 = np.expand_dims(w_1, axis=1)
w_1 = np.concatenate([np.real(w_1), np.imag(w_1)], 1) # shape: sample, 2, 32, 13
pilot_2 = np.load('Data/pilot_2.npz')['data']
# pilot_2 = pilot_2[split_idx:,...]
pilot_2 = np.expand_dims(pilot_2, axis=1)
pilot_2 = np.concatenate([np.real(pilot_2), np.imag(pilot_2)], 1) # shape: sample, 2, 4, 48, 4
w = w_1

# =======================================================================================================================
# =======================================================================================================================
# Score Calculating
def cos_sim(vector_a, vector_b):
	vector_a = np.mat(vector_a)
	vector_b = np.mat(vector_b)
	num = vector_a * vector_b.H
	num1 = np.sqrt(vector_a * vector_a.H)
	num2 = np.sqrt(vector_b * vector_b.H)
	cos = (num / (num1*num2))
	return cos.item()

def cal_score(w_true,w_pre):
	w_true = np.transpose(w_true, [0, 3, 2, 1])
	w_pre = np.transpose(w_pre, [0, 3, 2, 1])
	img_total = NUM_TX * 2
	BS = w_true.shape[0]
	num_sample_subband = BS*NUM_SUBBAND
	W_true = np.reshape(w_true, [num_sample_subband, img_total])
	W_pre = np.reshape(w_pre, [num_sample_subband, img_total])
	W_true2 = W_true[0:num_sample_subband, 0:int(img_total):2] + 1j*W_true[0:num_sample_subband, 1:int(img_total):2]
	W_pre2 = W_pre[0:num_sample_subband, 0:int(img_total):2] + 1j*W_pre[0:num_sample_subband, 1:int(img_total):2]
	score_cos = 0
	for i in range(num_sample_subband):
		W_true2_sample = W_true2[i:i+1,]
		W_pre2_sample = W_pre2[i:i+1,]
		score_tmp = cos_sim(W_true2_sample,W_pre2_sample)
		score_cos = score_cos + abs(score_tmp)*abs(score_tmp)
	score_cos = score_cos/num_sample_subband
	return score_cos
def seed_torch(seed=0):
	random.seed(seed)
	os.environ['PYTHONHASHSEED'] = str(seed)
	np.random.seed(seed)
	torch.manual_seed(seed)
	torch.cuda.manual_seed(seed)
	torch.backends.cudnn.benchmark = True
	torch.backends.cudnn.deterministic = True

seed_torch(123456)
wf = encFunction_1_gene(pilot_1, 'exp/enc/snapshot_c208_s1/best.pth')
wf_c48 = encFunction_2_gene(pilot_2, 'exp/enc/snapshot_c48_s1/best.pth')
np.savez_compressed('user_data/wf_ei_refine_temp.npz', data=wf)
np.savez_compressed('user_data/wf_c48_ei_refine_temp.npz', data=wf_c48)