python gene_wf.py
