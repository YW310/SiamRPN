# Copyright (c) SenseTime. All Rights Reserved.

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

from utils.config import cfg
from models.model_builder import ModelBuilder

MODELS = {
		  'TransWaic': ModelBuilder
		 }


def build_model(model_type):
	if not model_type in MODELS.keys():
		return ModelBuilder()
	return MODELS[model_type]()
