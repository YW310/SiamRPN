# Copyright (c) SenseTime. All Rights Reserved.

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
from models.cest.base import mdmlp_s

CEST = {
              'mdmlp_s': mdmlp_s,
            }

def get_cest(name, **kwargs):
    return CEST[name](**kwargs)
