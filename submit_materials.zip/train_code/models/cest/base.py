from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
import torch
import torch.nn as nn
from models.layers.mlp import MLPMDS
from einops import rearrange

class MDMLPS(nn.Module):
	def __init__(self, input_length=208, channel_dim=256,enhanced_input=False):
		super(MDMLPS, self).__init__()
		pilot_num = int(input_length / 8)
		emd_dim = 192
		out_dim = 8
		patch_size_h=1
		patch_size_w=2
		image_size_h=32
		image_size_w=52
		num_patch =  (image_size_h// patch_size_h) * (image_size_w// patch_size_w)
		self.mlp_mixer = MLPMDS(in_channels=8, dim=emd_dim, num_output=out_dim, 
								patch_size_h=patch_size_h, patch_size_w=patch_size_w, image_size_h=image_size_h, image_size_w=image_size_w, depth=3, token_dim=256, channel_dim=256)
		self.fc1 = nn.Linear(pilot_num, image_size_w)
		self.fc2 = nn.Linear(num_patch, image_size_h*image_size_w)
	
	def forward(self, x): #(batch, 2, 4, 208 or 48, 4)
		x = rearrange(x, 'b c rx (rb subc) sym -> b (c rx) (subc sym) rb', subc=8) # (batch,8,32,26 or 6)
		x = self.fc1(x) # (batch,8,32,52)
		out = self.mlp_mixer(x) # (batch, patch_num, out_dim)
		out = rearrange(out, 'b p o -> b o p')
		out = self.fc2(out) # (batch, 8, 52*32)
		out = rearrange(out, 'b (c rx) (tx rb) -> b c rx tx rb', rx=4, tx=32)
		return out

def mdmlp_s(**kwargs):
	return MDMLPS(**kwargs)