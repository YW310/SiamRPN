import argparse
import logging
import os
import time
import json
import random
import math
import numpy as np
import torch
import torch.nn as nn
from torch.nn.utils import clip_grad_norm_
from utils import pro_lmdb
from utils.config import cfg
from utils.lr_scheduler import build_lr_scheduler
from utils.log_helper import init_log, print_speed, add_file_handler
from utils.distributed import dist_init,dist_init_local, DistModule, reduce_gradients,\
		average_reduce, get_rank, get_world_size
from utils.average_meter import AverageMeter

from models.model_builder import ModelBuilder, cal_eigenvector_torch
from tensorboardX import SummaryWriter


logger = logging.getLogger('global')

def remove_prefix(state_dict, prefix):
	''' Old style model is stored with all names of parameters
	share common prefix 'module.' '''
	logger.info('remove prefix \'{}\''.format(prefix))
	f = lambda x: x.split(prefix, 1)[-1] if x.startswith(prefix) else x
	return {f(key): value for key, value in state_dict.items()}

def remove_prefix_swin(state_dict, prefix):
	logger.info('swin style: remove prefix \'{}\''.format(prefix))
	# f = lambda x: x.split(prefix, 1)[-1] if x.startswith(prefix) else x
	return {key: value for key, value in state_dict[prefix].items()}

def log_grads(model, tb_writer, tb_index):
	def weights_grads(model):
		grad = {}
		weights = {}
		for name, param in model.named_parameters():
			if param.grad is not None:
				grad[name] = param.grad
				weights[name] = param.data
		return grad, weights

	grad, weights = weights_grads(model)
	feature_norm, rpn_norm = 0, 0
	for k, g in grad.items():
		_norm = g.data.norm(2)
		weight = weights[k]
		w_norm = weight.norm(2)
		if 'feature' in k:
			feature_norm += _norm ** 2
		else:
			rpn_norm += _norm ** 2

		tb_writer.add_scalar('grad_all/'+k.replace('.', '/'),
							 _norm, tb_index)
		tb_writer.add_scalar('weight_all/'+k.replace('.', '/'),
							 w_norm, tb_index)
		tb_writer.add_scalar('w-g/'+k.replace('.', '/'),
							 w_norm/(1e-20 + _norm), tb_index)
	tot_norm = feature_norm + rpn_norm
	tot_norm = tot_norm ** 0.5
	feature_norm = feature_norm ** 0.5
	rpn_norm = rpn_norm ** 0.5

	tb_writer.add_scalar('grad/tot', tot_norm, tb_index)
	tb_writer.add_scalar('grad/feature', feature_norm, tb_index)
	tb_writer.add_scalar('grad/rpn', rpn_norm, tb_index)


def load_pretrain(model, pretrained_path, backbone = False,del_prev=False):
	if os.path.isfile(pretrained_path)==False:
		print("Not Found Model")
		return model
	logger.info('load pretrained model from {}'.format(pretrained_path))
	device = torch.cuda.current_device()
	pretrained_dict = torch.load(pretrained_path,
		map_location=lambda storage, loc: storage.cuda(device))

	if "model" in pretrained_dict.keys():
		pretrained_dict = remove_prefix_swin(pretrained_dict,
										'model')
	elif "state_dict" in pretrained_dict.keys():
		pretrained_dict = remove_prefix(pretrained_dict['state_dict'],
										'module.')
	else:
		pretrained_dict = remove_prefix(pretrained_dict, 'module.')
	
	model.load_state_dict(pretrained_dict, strict=False)


	return model



def check_keys(model, pretrained_state_dict):
	ckpt_keys = set(pretrained_state_dict.keys())
	model_keys = set(model.state_dict().keys())
	# print('ckpt_keys',ckpt_keys)
	# print('model_keys',model_keys)
	used_pretrained_keys = model_keys & ckpt_keys
	unused_pretrained_keys = ckpt_keys - model_keys
	missing_keys = model_keys - ckpt_keys
	# filter 'num_batches_tracked'
	missing_keys = [x for x in missing_keys
					if not x.endswith('num_batches_tracked')]
	if len(missing_keys) > 0:
		logger.info('[Warning] missing keys: {}'.format(missing_keys))
		logger.info('missing keys:{}'.format(len(missing_keys)))
	if len(unused_pretrained_keys) > 0:
		logger.info('[Warning] unused_pretrained_keys: {}'.format(
			unused_pretrained_keys))
		logger.info('unused checkpoint keys:{}'.format(
			len(unused_pretrained_keys)))
	logger.info('used keys:{}'.format(len(used_pretrained_keys)))
	assert len(used_pretrained_keys) > 0, \
		'load NONE from pretrained checkpoint'
	return True

def restore_from(model, optimizer, ckpt_path):
	device = torch.cuda.current_device()
	ckpt = torch.load(ckpt_path,
		map_location=lambda storage, loc: storage.cuda(device))
	epoch = ckpt['epoch']

	ckpt_model_dict = remove_prefix(ckpt['state_dict'], 'module.')
	check_keys(model, ckpt_model_dict)
	model.load_state_dict(ckpt_model_dict, strict=False)

	check_keys(optimizer, ckpt['optimizer'])
	optimizer.load_state_dict(ckpt['optimizer'])
	return model, optimizer, epoch


def cal_eigenvector(channel):
	"""
		Description:
			calculate the eigenvector on each subband
		Input:
			channel: np.array, channel in frequency domain,  shape [batch_size, rx_num, tx_num, subcarrier_num]
		Output:
			eigenvectors:  np.array, eigenvector for each subband, shape [batch_size, tx_num, subband_num]
	"""
	subband_num = 13
	hf_ = np.transpose(channel, [0,3,1,2]) # (batch,subcarrier_num,4,32)
	hf_h = np.conj(np.transpose(channel, [0,3,2,1])) # (batch,subcarrier_num,32,4)
	R = np.matmul(hf_h, hf_) # (batch,subcarrier_num,32,32)
	R = R.reshape(R.shape[0],subband_num,-1,R.shape[2],R.shape[3]).mean(axis=2) # average the R over each subband, (batch,13,32,32)
	[D,V] = np.linalg.eig(R)
	v = V[:,:,:,0]
	eigenvectors = np.transpose(v,[0,2,1])
	return eigenvectors

def cos_sim(vector_a, vector_b):
	vector_a = np.mat(vector_a)
	vector_b = np.mat(vector_b)
	num = vector_a * vector_b.H
	num1 = np.sqrt(vector_a * vector_a.H)
	num2 = np.sqrt(vector_b * vector_b.H)
	cos = (num / (num1*num2))
	return cos.item()

def cal_score(w_true,w_pre):
	NUM_TX = 32
	NUM_SUBBAND = 13
	BS = w_true.shape[0]
	w_true = np.transpose(w_true, [0, 3, 2, 1])
	w_pre = np.transpose(w_pre, [0, 3, 2, 1])
	img_total = NUM_TX * 2
	num_sample_subband = BS*NUM_SUBBAND #NUM_SAMPLES * NUM_SUBBAND
	W_true = np.reshape(w_true, [num_sample_subband, img_total])
	W_pre = np.reshape(w_pre, [num_sample_subband, img_total])
	W_true2 = W_true[0:num_sample_subband, 0:int(img_total):2] + 1j*W_true[0:num_sample_subband, 1:int(img_total):2]
	W_pre2 = W_pre[0:num_sample_subband, 0:int(img_total):2] + 1j*W_pre[0:num_sample_subband, 1:int(img_total):2]
	score_cos = 0
	for i in range(num_sample_subband):
		W_true2_sample = W_true2[i:i+1,]
		W_pre2_sample = W_pre2[i:i+1,]
		score_tmp = cos_sim(W_true2_sample,W_pre2_sample)
		score_cos = score_cos + abs(score_tmp)*abs(score_tmp)
	score_cos = score_cos/num_sample_subband
	return score_cos

def seed_torch(seed=0):
	random.seed(seed)
	os.environ['PYTHONHASHSEED'] = str(seed)
	np.random.seed(seed)
	torch.manual_seed(seed)
	torch.cuda.manual_seed(seed)
	torch.backends.cudnn.benchmark = True
	torch.backends.cudnn.deterministic = True

def build_opt_lr(model, current_epoch=0):
	#set the condition for channel estimation model training.
	if cfg.UPS.UPS:
		if current_epoch >= cfg.UPS.TRAIN_EPOCH:
			for param in model.ups.parameters():
				param.requires_grad = True
			for m in model.ups.modules():
				if isinstance(m, nn.BatchNorm2d):
					m.train()
		else:
			for param in model.cest.parameters():
				param.requires_grad = False
			for m in model.cest.modules():
				if isinstance(m, nn.BatchNorm2d):
					m.eval()
	
	if cfg.CEST.CEST:
		if current_epoch >= cfg.CEST.TRAIN_EPOCH:
			for param in model.cest.parameters():
				param.requires_grad = True
			for m in model.cest.modules():
				if isinstance(m, nn.BatchNorm2d):
					m.train()
		else:
			for param in model.cest.parameters():
				param.requires_grad = False
			for m in model.cest.modules():
				if isinstance(m, nn.BatchNorm2d):
					m.eval()
	
	if cfg.CSI.CSI:
		if current_epoch >= cfg.CSI.TRAIN_EPOCH:
			for param in model.csi.parameters():
				param.requires_grad = False
			for m in model.csi.modules():
				if isinstance(m, nn.BatchNorm2d):
					m.eval()
				if isinstance(m, nn.LayerNorm):
					m.eval()
			
			for layer in cfg.CSI.TRAIN_LAYER:
				for param in getattr(model.csi, layer).parameters(): # model.csi.parameters():
					param.requires_grad = True
				for m in getattr(model.csi, layer).modules(): # model.csi.modules():
					if isinstance(m, nn.BatchNorm2d):
						m.train()
					if isinstance(m, nn.LayerNorm):
						m.train()
		else:
			for param in model.csi.parameters():
				param.requires_grad = False
			for m in model.csi.modules():
				if isinstance(m, nn.BatchNorm2d):
					m.eval()
				if isinstance(m, nn.LayerNorm):
					m.eval()
	
	# set trainable paramerters
	trainable_params = []
	if cfg.UPS.UPS:
		trainable_params += [{'params': model.ups.parameters(),
							  'lr': cfg.UPS.LAYERS_LR*cfg.TRAIN.BASE_LR}]
	if cfg.CEST.CEST:
		trainable_params += [{'params': model.cest.parameters(),
							  'lr': cfg.CEST.LAYERS_LR*cfg.TRAIN.BASE_LR}]
	if cfg.CSI.CSI:
		# trainable_params += [{'params': model.csi.parameters(),
							#   'lr': cfg.CSI.LAYERS_LR*cfg.TRAIN.BASE_LR}]
		trainable_params += [{'params': filter(lambda x: x.requires_grad,model.csi.parameters()),
							'lr': cfg.CSI.LAYERS_LR * cfg.TRAIN.BASE_LR}]

	if cfg.TRAIN.OPTIMIZER == 'SGD':
		optimizer = torch.optim.SGD(trainable_params,
									momentum=cfg.TRAIN.MOMENTUM,
									weight_decay=cfg.TRAIN.WEIGHT_DECAY)
	elif cfg.TRAIN.OPTIMIZER == 'ADAM':
		# Adam(params, lr: float, betas: Tuple[float, float], eps: float, weight_decay: float, amsgrad: bool) -> None
		optimizer = torch.optim.Adam(trainable_params,weight_decay=cfg.TRAIN.WEIGHT_DECAY)
	elif cfg.TRAIN.OPTIMIZER == 'ADAMW':
		optimizer = torch.optim.AdamW(trainable_params, weight_decay=cfg.TRAIN.WEIGHT_DECAY)
	else:
		raise NotImplementedError

	lr_scheduler = build_lr_scheduler(optimizer, epochs=cfg.TRAIN.EPOCH)
	lr_scheduler.step(cfg.TRAIN.START_EPOCH)
	return optimizer, lr_scheduler

def build_data_loader():
	if cfg.DATASET.LMDB:
		train_dataset = pro_lmdb.ImageFolderLMDB(cfg.DATASET.WAIC.ROOT,transform=None)
	else:
		train_dataset = pro_lmdb.Dataset()
	
	train_sampler = None
	if get_world_size() > 1:
		train_sampler = torch.utils.data.distributed.DistributedSampler(train_dataset)
	
	train_loader = torch.utils.data.DataLoader(
		train_dataset, batch_size=cfg.TRAIN.BATCH_SIZE, shuffle=(train_sampler is None),
		num_workers=cfg.TRAIN.NUM_WORKERS, pin_memory=True, sampler=train_sampler, persistent_workers=True)
	return train_loader

def build_val_loader():
	if cfg.VALSET.VALSET == False:
		return None
	logger.info("build val dataset")
	if cfg.VALSET.LMDB:
		val_dataset = pro_lmdb.ImageFolderLMDB(cfg.VALSET.WAIC.ROOT,transform=None)
	else:
		val_dataset = pro_lmdb.DatasetVal()

	logger.info("build val done")
	val_loader = torch.utils.data.DataLoader(val_dataset,
							  batch_size=512,num_workers=2,
							  pin_memory=True,sampler=None,persistent_workers=True)
	return val_loader

def main(args):
	if args.local:
		rank, world_size = dist_init_local(args.gpu_id)
	else:
		rank, world_size = dist_init()
	cfg.merge_from_file(args.config)
	if rank == 0:
		if not os.path.exists(cfg.TRAIN.LOG_DIR):
			os.makedirs(cfg.TRAIN.LOG_DIR)
		init_log('global', logging.INFO)
		if cfg.TRAIN.LOG_DIR:
			add_file_handler('global',
							 os.path.join(cfg.TRAIN.LOG_DIR, 'logs.txt'),
							 logging.INFO)

		logger.info("config \n{}".format(json.dumps(cfg, indent=4)))
	
	model = ModelBuilder()
	
	if cfg.TRAIN.PRETRAINED != '':
		model = load_pretrain(model, cfg.TRAIN.PRETRAINED)
		print('whole-model loaded: ',cfg.TRAIN.PRETRAINED )
	
	if cfg.CEST.PRETRAINED != '':
		model = load_pretrain(model, cfg.CEST.PRETRAINED)
		print('cest-model loaded: ',cfg.CEST.PRETRAINED )

	model = model.cuda().train()
	if not args.local:
		dist_model = DistModule(model)
	else:
		dist_model = model
	
	# create tensorboard writer
	if rank == 0 and cfg.TRAIN.LOG_DIR:
		tb_writer = SummaryWriter(cfg.TRAIN.LOG_DIR)
	else:
		tb_writer = None

	train_loader = build_data_loader()
	val_loader = build_val_loader()
	if args.local:
		optimizer, lr_scheduler = build_opt_lr(dist_model,
											cfg.TRAIN.START_EPOCH)
	else: 
		optimizer, lr_scheduler = build_opt_lr(dist_model.module,
											cfg.TRAIN.START_EPOCH)
	if args.resume != '':
		if os.path.isfile(args.resume):
			logger.info("resume from {}".format(args.resume))
			model, optimizer, cfg.TRAIN.START_EPOCH = restore_from(model, optimizer, args.resume)
		else:
			logger.info("{} is not a valid file".format(args.resume))


	print('parameters: {}'.format(sum([p.data.nelement() for p in model.parameters()])))
	print('training params:', sum(p.numel() for p in dist_model.parameters() if p.requires_grad))
	logger.info(lr_scheduler)
	logger.info("model prepare done")

	train(args, train_loader, val_loader, dist_model, optimizer, lr_scheduler, tb_writer)

def train(args, train_loader, val_loader, model, optimizer, lr_scheduler, tb_writer):
	cur_lr = lr_scheduler.get_cur_lr()
	rank = get_rank()
	average_meter = AverageMeter()
	def is_valid_number(x):
		return not(math.isnan(x) or math.isinf(x) or x > 1e4)
	world_size = get_world_size()
	num_per_epoch = len(train_loader.dataset) // (cfg.TRAIN.BATCH_SIZE * world_size)
	start_epoch = cfg.TRAIN.START_EPOCH
	epoch = start_epoch

	if not os.path.exists(cfg.TRAIN.SNAPSHOT_DIR) and get_rank() == 0:
		os.makedirs(cfg.TRAIN.SNAPSHOT_DIR)

	end = time.time()
	model.zero_grad()
	best_score = 0.735
	for epoch in range(cfg.TRAIN.EPOCH):
		for idx, pg in enumerate(optimizer.param_groups):
			logger.info('epoch {} lr {}'.format(epoch+1, pg['lr']))
		if rank == 0 and cfg.CEST.TRAIN_EPOCH==epoch:
			logger.info('start to train CEST')
			if args.local:
				optimizer, lr_scheduler = build_opt_lr(model,epoch)
			else: 
				optimizer, lr_scheduler = build_opt_lr(model.module,epoch)
			print('parameters: {}'.format(sum([p.data.nelement() for p in model.parameters()])))
			print('training params:', sum(p.numel() for p in model.parameters() if p.requires_grad))
			logger.info(lr_scheduler)
			# logger.info("model\n{}".format(describe(model.module)))
		for idx,(pilot_h, pilot_l, hf, w, wf_h, wf_l,wf_h_g, wf_l_g) in enumerate(train_loader): 
			tb_idx = idx + epoch*num_per_epoch
			data_time = average_reduce(time.time() - end)
			if rank == 0:
				tb_writer.add_scalar('time/data', data_time, tb_idx)
			if cfg.TRAIN.TRAIN == 'ups':
				outputs = model(pilot_l, hf, w, pilot_h)
			else:
				if cfg.CEST.KWARGS.input_length == 208 or cfg.CEST.KWARGS.input_length == 416:
					#	def forward(self, pilot, hf, w, pilot_h= None, wf=None):
					outputs = model(pilot_h, hf, w, wf_h, wf_h_g, wf_l_g, train_flag=True)
				elif cfg.CEST.KWARGS.input_length == 48 or cfg.CEST.KWARGS.input_length == 96:
					outputs = model(pilot_l, hf, w, wf_l, wf_h_g, wf_l_g, train_flag=True)
				else:
					NotImplementedError

			loss = outputs['total_loss']
			if is_valid_number(loss.data.item()):
				optimizer.zero_grad()
				loss.backward()
				if not args.local:
					reduce_gradients(model)
				if rank == 0 and cfg.TRAIN.LOG_GRADS:
					log_grads(model.module, tb_writer, tb_idx)
				clip_grad_norm_(model.parameters(), cfg.TRAIN.GRAD_CLIP)
				optimizer.step()
			
			batch_time = time.time() - end
			batch_info = {}
			batch_info['batch_time'] = average_reduce(batch_time)
			batch_info['data_time'] = average_reduce(data_time)
			for k, v in sorted(outputs.items()):
				if v.data.dim() == 0:
					batch_info[k] = average_reduce(v.data.item())

			average_meter.update(**batch_info)
			if rank == 0:
				for k, v in batch_info.items():
					tb_writer.add_scalar(k, v, tb_idx)

				if (idx+1) % cfg.TRAIN.PRINT_FREQ == 0:
					info = "Epoch: [{}][{}/{}] lr: {:.6f}\n".format(
								epoch+1, (idx+1) % num_per_epoch,
								num_per_epoch, cur_lr)
					for cc, (k, v) in enumerate(batch_info.items()):
						if cc % 2 == 0:
							info += ("\t{:s}\t").format(
									getattr(average_meter, k))
						else:
							info += ("{:s}\n").format(
									getattr(average_meter, k))
					logger.info(info)
					print_speed(idx+1+epoch*num_per_epoch,
								average_meter.batch_time.avg,
								cfg.TRAIN.EPOCH * num_per_epoch)
			end = time.time()
		if get_rank() == 0 and epoch>=cfg.TRAIN.VALEPOCH:	
			if val_loader!=None: 
				with torch.no_grad(): 
					loss_val = 0.0
					score_val = 0.0
					score_val_2 = 0.0 #(pilot_h, pilot_l, hf, w, wf_h, wf_l)
					# w_val_arr = None
					# wf_p_arr = None
					for idx_val, (pilot_h_val, pilot_l_val, hf_val, w_val, wf_h_val, wf_l_val,wf_h_g, wf_l_g) in enumerate(val_loader):
						if idx_val == 0:
							w_val_arr = w_val.cpu().numpy()
						else:
							w_val_arr = np.concatenate((w_val_arr, w_val.cpu().numpy()), axis=0)

						if cfg.CEST.KWARGS.input_length == 208 or cfg.CEST.KWARGS.input_length == 416:
							#	def forward(self, pilot, hf, w, pilot_h= None, wf=None):
							outputs_val = model(pilot_h_val, hf_val, w_val, wf_h_val, train_flag=False)
						elif cfg.CEST.KWARGS.input_length == 48 or cfg.CEST.KWARGS.input_length == 96:
							outputs_val = model(pilot_l_val, hf_val, w_val, wf_l_val, train_flag=False)
						else:
							NotImplementedError

						if cfg.TRAIN.TRAIN == 'enc':
							hf_p_val = outputs_val['hf_p']
							# step 2: eigenvector calculation
							h_complex = hf_p_val[:,0,...] + 1j*hf_p_val[:,1,...] # (batch,4,32,52)
							v = cal_eigenvector(h_complex.cpu().numpy())
							# v2 = cal_eigenvector_torch(h_complex)
							# step 3: eigenvector compression
							w_complex = torch.from_numpy(v)
							w = torch.zeros([hf_p_val.shape[0], 2, 32, 13], dtype=torch.float32).cuda() # (batch,2,32,13)
							w[:,0,:,:] = torch.real(w_complex)
							w[:,1,:,:] = torch.imag(w_complex)
							wf_p = w.cpu().numpy()
							if idx_val == 0:
								wf_p_arr = wf_p
							else:
								wf_p_arr = np.concatenate((wf_p_arr, wf_p), axis=0)
						elif cfg.TRAIN.TRAIN == 'dec' or cfg.TRAIN.TRAIN == 'dec_wo_cest' or cfg.TRAIN.TRAIN == 'casdec':
							wf_p = outputs_val['wf_p']
							# wf = outputs_val['wf']
							# score_val += cal_score(w_val,wf_p.cpu().numpy())
							# score_val_2 += cal_score(w_val,wf.cpu().numpy())
							if idx_val == 0:
								wf_p_arr = wf_p.cpu().numpy()
							else:
								wf_p_arr = np.concatenate((wf_p_arr, wf_p.cpu().numpy()), axis=0)
						else:
							NotImplementedError
						loss_val += outputs_val['total_loss'].item()
						
					# cal loss on validation set
					loss_val = loss_val/(idx_val+1)
					score_val = cal_score(w_val_arr, wf_p_arr)	
					logger.info('loss_val:{}\nscore_val:{},\n'.format(loss_val,score_val))
					if score_val>best_score:
						best_score = score_val
						torch.save(
							{'epoch': epoch,
							'state_dict':model.state_dict() if args.local else model.module.state_dict(),
							# 'optimizer': optimizer
							},
							cfg.TRAIN.SNAPSHOT_DIR+'/best.pth')
							
		if get_rank() == 0 and epoch>=cfg.TRAIN.SAVEEPOCH:
			torch.save(
				{'epoch': epoch,
				'state_dict':model.state_dict() if args.local else model.module.state_dict(),
				# 'optimizer': optimizer
				},
				cfg.TRAIN.SNAPSHOT_DIR+'/checkpoint_e%d.pth' % (epoch))
		lr_scheduler.step(epoch)
		cur_lr = lr_scheduler.get_cur_lr()
		logger.info('epoch: {}'.format(epoch+1))

if __name__ == '__main__':
	parser = argparse.ArgumentParser(description='Test LMDB file')
	parser.add_argument('--config', type=str, default='exp/enc/config_s2.yaml',help='configuration of tracking')
	parser.add_argument('--gpu_id', default=0,type=int, help='gpu_id')
	parser.add_argument('--local_rank', type=int, default=0, help='compulsory for pytorch launcer')
	parser.add_argument("--local", dest='local', action="store_true",help="Run or not.")
	parser.add_argument("--resume", default='', help="resume")
	parser.set_defaults(local=False)
	args = parser.parse_args()
	seed_torch(123456)
	main(args)