# Copyright (c) SenseTime. All Rights Reserved.

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

from yacs.config import CfgNode as CN

__C = CN()

cfg = __C

__C.META_ARC = "transwaic"

__C.INFERENCE = False

__C.UPS = CN()
__C.UPS.UPS =False
__C.UPS.TYPE = 'ups'
__C.UPS.KWARGS = CN(new_allowed=True)
__C.UPS.PRETRAINED = ''
__C.UPS.LAYERS_LR = 0.1
__C.UPS.TRAIN_EPOCH = 0

__C.CEST = CN()
__C.CEST.CEST =False
__C.CEST.TYPE = 'mix'
__C.CEST.ENHANCEIN = False
__C.CEST.KWARGS = CN(new_allowed=True)
__C.CEST.PRETRAINED = ''
__C.CEST.LAYERS_LR = 0.1
__C.CEST.TRAIN_EPOCH = 0

__C.CSI = CN()
__C.CSI.CSI =False
__C.CSI.TYPE = 'ae'
__C.CSI.KWARGS = CN(new_allowed=True)
__C.CSI.PRETRAINED = ''
__C.CSI.TTANUM = 5
__C.CSI.LAYERS_LR = 0.1
__C.CSI.TRAIN_EPOCH = 0
__C.CSI.TRAIN_LAYER = ['encoder', 'decoder']

__C.TRAIN = CN()
__C.TRAIN.TRAIN = 'enc'
__C.TRAIN.LABEL=['HF','W', 'wf','PL','PH']
__C.TRAIN.WEIGHT = [1.0,]
__C.TRAIN.PREDICTION =['hf_p']
__C.TRAIN.GT = ['HF']
__C.TRAIN.LOSS  = ['MSE']
__C.TRAIN.EPOCH = 20
__C.TRAIN.SAVEEPOCH = 20
__C.TRAIN.VALEPOCH = 20
__C.TRAIN.START_EPOCH = 0
__C.TRAIN.BATCH_SIZE = 32
__C.TRAIN.NUM_WORKERS = 1
__C.TRAIN.MOMENTUM = 0.9
__C.TRAIN.WEIGHT_DECAY = 0.0001
__C.TRAIN.OPTIMIZER = 'SGD'
__C.TRAIN.BASE_LR = 0.001
__C.TRAIN.GRAD_CLIP = 1.0
__C.TRAIN.PRETRAINED = ''
__C.TRAIN.SNAPSHOT_DIR = './snapshot'
__C.TRAIN.LOG_DIR = './logs'
__C.TRAIN.PRINT_FREQ = 20
__C.TRAIN.LOG_GRADS = False
__C.TRAIN.LR = CN()
__C.TRAIN.LR.TYPE = 'log'
__C.TRAIN.LR.KWARGS = CN(new_allowed=True)

__C.TRAIN.LR_WARMUP = CN()
__C.TRAIN.LR_WARMUP.WARMUP = False
__C.TRAIN.LR_WARMUP.TYPE = 'step'
__C.TRAIN.LR_WARMUP.EPOCH = 5
__C.TRAIN.LR_WARMUP.KWARGS = CN(new_allowed=True)

__C.TEST = CN()
__C.VAL = CN()
__C.VAL.VAL = False

__C.DATASET = CN(new_allowed=True)
__C.DATASET.NAMES =  ('WAIC',)
__C.DATASET.VIDEOS_PER_EPOCH = 300000
__C.DATASET.WAIC = CN(new_allowed=True)
__C.DATASET.WAIC.ROOT = 'waic/train'
__C.DATASET.LMDB = False
__C.DATASET.FLIP = 0.0
__C.DATASET.NOISE = 0.0
__C.DATASET.NOISEVAL = 0.005
__C.DATASET.MIXUP = 0.0
__C.DATASET.MIXW = 0.0
__C.DATASET.MIXWF = 0.0
__C.DATASET.VALSHIFT = 0.0
__C.DATASET.PILOTFUSE = 0.0
__C.DATASET.SWITCH = 0.0
__C.DATASET.OPPOSITE = 0.0

__C.DATASET.LTSPOT = CN()
__C.DATASET.LTSPOT.LTSPOT = 0.0
__C.DATASET.LTSPOT.SIGMA_X = (15,20)
__C.DATASET.LTSPOT.SIGMA_Y = (10,15)
__C.DATASET.LTSPOT.DEGREE = (0.5,1.5)

__C.DATASET.WFH = '/home/sr5/yiwei.chen/transwaic/Data/wf_1.npz'
__C.DATASET.WFL = '/home/sr5/yiwei.chen/transwaic/Data/wf_2.npz'

__C.VALSET = CN(new_allowed=True)
__C.VALSET.VALSET =  False
__C.VALSET.WAIC = CN(new_allowed=True)
__C.VALSET.WAIC.ROOT = 'waic/val'
__C.VALSET.LMDB = False


__C.LOSS  = CN()
__C.LOSS.TYPE = ['MSE_TORCH','CE_TORCH','WAIC', 'COSSIM','L1','NMSE','COSSIM_TORCH']
__C.LOSS.MSE_TORCH  = CN()
__C.LOSS.MSE_TORCH.KWARGS = CN(new_allowed=True)
__C.LOSS.CE_TORCH  = CN()
__C.LOSS.CE_TORCH.KWARGS = CN(new_allowed=True)
__C.LOSS.WAIC  = CN()
__C.LOSS.WAIC.KWARGS = CN(new_allowed=True)
__C.LOSS.COSSIM  = CN()
__C.LOSS.COSSIM.KWARGS = CN(new_allowed=True)
__C.LOSS.L1  = CN()
__C.LOSS.L1.KWARGS = CN(new_allowed=True)
__C.LOSS.NMSE  = CN()
__C.LOSS.NMSE.KWARGS = CN(new_allowed=True)
__C.LOSS.L1  = CN()
__C.LOSS.L1.KWARGS = CN(new_allowed=True)
__C.LOSS.L1  = CN()
__C.LOSS.L1.KWARGS = CN(new_allowed=True)
__C.LOSS.COSSIM_TORCH  = CN()
__C.LOSS.COSSIM_TORCH.KWARGS = CN(new_allowed=True)