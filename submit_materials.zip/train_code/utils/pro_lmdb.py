import os
import sys
sys.path.append('/home/sr5/yiwei.chen/transwaic/')
import six
import string
import argparse

import lmdb
import pickle
import msgpack
import tqdm
from PIL import Image
import numpy as np
import torch
import torch.utils.data as data
from torch.utils.data import DataLoader
from torchvision.transforms import transforms
from torchvision import transforms, datasets
# This segfaults when imported before torch: https://github.com/apache/arrow/issues/2637
import pyarrow as pa
from utils.config import cfg
import random

def gene_higher_pilot(data):
	data_complex = data[:, 0, ...] + 1j * data[:, 1, ...]
	data_2order = data_complex * (np.abs(data_complex) ** 2)
	data_complex = np.concatenate([data_complex, data_2order], 2)
	data_complex = np.expand_dims(data_complex, axis=1)
	data_complex = np.concatenate([np.real(data_complex), np.imag(data_complex)],
								1)  # shape: sample, 2, 4, 208, 4
	return data_complex

def mixup(x, y, lam=0.5):
	x = x*(1-lam) + y*lam
	return x
#
class Dataset(data.Dataset):
	def __init__(self, splite_ratio=0.98):
		# __C.TRAIN.LABEL=['HF','W', 'wf','PL','PH']
		self.HF = self.W  = self.wf = self.wf_h = self.wf_l = self.PL = self.PH = None
		split_idx = -1
		self.length = 0
		if 'HF' in cfg.TRAIN.LABEL:
			HF = np.load('/home/sr5/yiwei.chen/transwaic/Data/hf.npz')['data']
			HF = np.expand_dims(HF, axis=1)
			HF = np.concatenate([np.real(HF), np.imag(HF)], 1)
			self.length = HF.shape[0]
			split_idx = int(splite_ratio * self.length)
			self.HF = HF[:split_idx,...]
		if 'W' in cfg.TRAIN.LABEL:
			W = np.load('/home/sr5/yiwei.chen/transwaic/Data/w.npz')['data']#,mmap_mode='r'
			W = np.expand_dims(W, axis=1)
			W = np.concatenate([np.real(W), np.imag(W)], 1)
			self.length = W.shape[0]
			split_idx = int(splite_ratio * self.length)
			self.W = W[:split_idx,...]
		if 'wf_h' in cfg.TRAIN.LABEL:
			wf_h = np.load(cfg.DATASET.WFH)['data']#,mmap_mode='r'
			split_idx = int(splite_ratio * self.length)
			self.wf_h = wf_h[:split_idx,...]
		if 'wf_l' in cfg.TRAIN.LABEL:
			wf_l = np.load(cfg.DATASET.WFL)['data']#,mmap_mode='r'
			split_idx = int(splite_ratio * self.length)
			self.wf_l = wf_l[:split_idx,...]
		# if 'wf' in cfg.TRAIN.LABEL:
		# 	wf = np.load('Data/w.npz')['data']#,mmap_mode='r'
		# 	wf= np.expand_dims(wf, axis=1)
		# 	wf = np.concatenate([np.real(wf), np.imag(wf)], 1)
		if 'PH' in cfg.TRAIN.LABEL:
			PH = np.load('/home/sr5/yiwei.chen/transwaic/Data/pilot_1.npz')['data']
			PH = np.expand_dims(PH, axis=1)
			PH = np.concatenate([np.real(PH), np.imag(PH)], 1)
			self.length = PH.shape[0]
			split_idx = int(splite_ratio * self.length)
			self.PH = PH[:split_idx,...]
			if cfg.CEST.ENHANCEIN:
				self.PH =gene_higher_pilot(self.PH)
		if 'PL' in cfg.TRAIN.LABEL:
			PL = np.load('/home/sr5/yiwei.chen/transwaic/Data/pilot_2.npz')['data']
			PL = np.expand_dims(PL, axis=1)
			PL = np.concatenate([np.real(PL), np.imag(PL)], 1)
			self.length = PL.shape[0]
			split_idx = int(splite_ratio * self.length)
			self.PL = PL[:split_idx,...]
			if cfg.DATASET.PILOTFUSE:
				pass
			if cfg.CEST.ENHANCEIN:
				self.PL =gene_higher_pilot(self.PL)

	def rand_choose_from_range(self,range):
		ret = range[0] + np.random.rand()*(range[1]-range[0])
		return ret
	
	def _light_spot_aug(self, image, bbox=None):
		degree  = self.rand_choose_from_range(cfg.DATASET.LTSPOT.DEGREE )
		sigma_x = self.rand_choose_from_range(cfg.DATASET.LTSPOT.SIGMA_X)
		sigma_y = self.rand_choose_from_range(cfg.DATASET.LTSPOT.SIGMA_Y)
		c, h, w = image.shape

		shift_x = self.rand_choose_from_range((0,h))
		x = torch.arange(-(h//2),h//2)
		shift_x_norm = shift_x-h//2
		temp = -((x-shift_x_norm)**2)/(2*(sigma_x)**2)
		gauss_1d_map_x = torch.exp(temp.float())

		shift_y = self.rand_choose_from_range((0,w))
		if w%2 ==0:
			y = torch.arange(-(w//2),w//2)
		else:
			y = torch.arange(-(w//2),w//2+1)
		shift_y_norm = shift_y-w//2
		temp = -((y-shift_y_norm)**2)/(2*(sigma_y)**2)
		gauss_1d_map_y = torch.exp(temp.float())
		
		gauss_2d_map = gauss_1d_map_x.view(h,1)*gauss_1d_map_y.view(1*w)
		gauss_2d_map = gauss_2d_map.unsqueeze(0)
		gauss_2d_map = gauss_2d_map.repeat(2,1,1)
		gauss_2d_map = gauss_2d_map.numpy()
		image_flag = (image>0).astype(np.int32)
		image_flag = (image_flag-0.5)*2
		image +=  gauss_2d_map*degree*image_flag
		
		return image

	def __getitem__(self, index):
		hf = w = ph = pl = wf_h = wf_l = np.array([-1])
		len_data =  int(self.length*0.98)
		index = index%len_data

		if 'HF' in cfg.TRAIN.LABEL:
			hf = self.HF[index]
		if 'W' in cfg.TRAIN.LABEL:
			w = self.W[index]
		if 'PH' in cfg.TRAIN.LABEL:
			ph = self.PH[index]
		if 'PL' in cfg.TRAIN.LABEL:
			pl = self.PL[index]
		if 'wf_h' in cfg.TRAIN.LABEL:
			wf_h = self.wf_h[index]
		if 'wf_l' in cfg.TRAIN.LABEL:
			wf_l = self.wf_l[index]
		
		if np.random.rand(1) < cfg.DATASET.MIXUP:
			lam = np.random.rand(1).astype(np.float32)
			lam = lam * 0.25
			mix_idx = np.random.randint(0, len_data-1)
			if 'HF' in cfg.TRAIN.LABEL:
				hf = mixup(hf, self.HF[mix_idx], lam)
			if 'W' in cfg.TRAIN.LABEL:
				w = mixup(w, self.W[mix_idx], lam)
			if 'PH' in cfg.TRAIN.LABEL:
				ph = mixup(ph, self.PH[mix_idx], lam)
			if 'PL' in cfg.TRAIN.LABEL:
				pl = mixup(pl, self.PL[mix_idx], lam)
			if 'wf_h' in cfg.TRAIN.LABEL:
				wf_h = mixup(wf_h, self.wf_h[mix_idx], lam)
			if 'wf_l' in cfg.TRAIN.LABEL:
				wf_l = mixup(wf_l, self.wf_l[mix_idx], lam)
		
		if np.random.rand(1) < cfg.DATASET.SWITCH:
			def switch(x):
				x = np.flip(x,axis=0)
				x = x.copy()
				return x
			if 'W' in cfg.TRAIN.LABEL:
				w = switch(w)
			if 'wf_h' in cfg.TRAIN.LABEL:
				wf_h = switch(wf_h)
			if 'wf_l' in cfg.TRAIN.LABEL:
				wf_l = switch(wf_l)
		if np.random.rand(1) < cfg.DATASET.MIXWF:
			wf_h = wf_l
			wf_l = wf_h
		if np.random.rand(1) < cfg.DATASET.MIXW:
			wf_h = w
			wf_l = w
		if np.random.rand(1) < cfg.DATASET.VALSHIFT:
			valshift = 1 + np.random.randn(1)*0.1
			wf_h *= valshift
			wf_l *= valshift
		if np.random.rand(1) < cfg.DATASET.OPPOSITE:
			wf_h *= -1
			wf_l *= -1
		if np.random.rand(1) < cfg.DATASET.LTSPOT.LTSPOT:
			wf_h_g = self._light_spot_aug(wf_h)
			wf_l_g = self._light_spot_aug(wf_l)
		else:
			wf_h_g = wf_h
			wf_l_g = wf_l
		return ph,pl,hf,w, wf_h, wf_l, wf_h_g, wf_l_g
	def __len__(self):
		return cfg.DATASET.VIDEOS_PER_EPOCH
		# return int(self.length*0.98)

class DatasetVal(data.Dataset):
	def __init__(self, splite_ratio=0.98):
		# __C.TRAIN.LABEL=['HF','W', 'wf','PL','PH']
		self.HF = self.W  = self.wf = self.wf_h = self.wf_l = self.PL = self.PH = None
		split_idx = -1
		self.length = 0
		if 'HF' in cfg.TRAIN.LABEL:
			HF = np.load('/home/sr5/yiwei.chen/transwaic/Data/hf.npz')['data']
			HF = np.expand_dims(HF, axis=1)
			HF = np.concatenate([np.real(HF), np.imag(HF)], 1)
			self.length = HF.shape[0]
			split_idx = int(splite_ratio * self.length)
			self.HF = HF[split_idx:,...]
		if 'W' in cfg.TRAIN.LABEL:
			W = np.load('/home/sr5/yiwei.chen/transwaic/Data/w.npz')['data']#,mmap_mode='r'
			W = np.expand_dims(W, axis=1)
			W = np.concatenate([np.real(W), np.imag(W)], 1)
			self.length = W.shape[0]
			split_idx = int(splite_ratio * self.length)
			self.W = W[split_idx:,...]
		if 'wf_h' in cfg.TRAIN.LABEL:
			wf_h = np.load(cfg.DATASET.WFH)['data']#,mmap_mode='r'
			split_idx = int(splite_ratio * self.length)
			self.wf_h = wf_h[split_idx:,...]
		if 'wf_l' in cfg.TRAIN.LABEL:
			wf_l = np.load(cfg.DATASET.WFL)['data']#,mmap_mode='r'
			split_idx = int(splite_ratio * self.length)
			self.wf_l = wf_l[split_idx:,...]
		if 'PH' in cfg.TRAIN.LABEL:
			PH = np.load('/home/sr5/yiwei.chen/transwaic/Data/pilot_1.npz')['data']
			PH = np.expand_dims(PH, axis=1)
			PH = np.concatenate([np.real(PH), np.imag(PH)], 1)
			self.length = PH.shape[0]
			split_idx = int(splite_ratio * self.length)
			self.PH = PH[split_idx:,...]
			if cfg.CEST.ENHANCEIN:
				self.PH =gene_higher_pilot(self.PH)
		if 'PL' in cfg.TRAIN.LABEL:
			PL = np.load('/home/sr5/yiwei.chen/transwaic/Data/pilot_2.npz')['data']
			PL = np.expand_dims(PL, axis=1)
			PL = np.concatenate([np.real(PL), np.imag(PL)], 1)
			self.length = PL.shape[0]
			split_idx = int(splite_ratio * self.length)
			self.PL = PL[split_idx:,...]
			if cfg.CEST.ENHANCEIN:
				self.PL =gene_higher_pilot(self.PL)
		
	def __getitem__(self, index):
		hf = w = ph = pl = wf_h = wf_l = wf_h_g = wf_l_g = np.array([-1])
		if 'HF' in cfg.TRAIN.LABEL:
			hf = self.HF[index]
		if 'W' in cfg.TRAIN.LABEL:
			w = self.W[index]
		if 'PH' in cfg.TRAIN.LABEL:
			ph = self.PH[index]
		if 'PL' in cfg.TRAIN.LABEL:
			pl = self.PL[index]
		if 'wf_h' in cfg.TRAIN.LABEL:
			wf_h = self.wf_h[index]
		if 'wf_l' in cfg.TRAIN.LABEL:
			wf_l = self.wf_l[index]
		return ph,pl,hf,w, wf_h, wf_l, wf_h_g, wf_l_g
	def __len__(self):
		return int(self.length*0.02)

class DatasetFolder(data.Dataset):
	def __init__(self, p_h, p_l, hf, w):
		self.pilot_h, self.pilot_l, self.label_hf,self.label_w = p_h, p_l, hf, w
	def __getitem__(self, index):
		return self.pilot_h[index], self.pilot_l[index], self.label_hf[index], self.label_w[index]
	def __len__(self):
		return self.pilot_h.shape[0]


class ImageFolderLMDB(data.Dataset):
	def __init__(self, db_path, transform=None, target_transform=None):
		self.db_path = db_path
		self.env = lmdb.open(db_path, subdir=os.path.isdir(db_path),
							 readonly=True, lock=False,
							 readahead=False, meminit=False)
		with self.env.begin(write=False) as txn:
			# self.length = txn.stat()['entries'] - 1
			self.length = pa.deserialize(txn.get(b'__len__'))
			self.keys = pa.deserialize(txn.get(b'__keys__'))
		
		
		# videos_per_epoch = cfg.DATASET.VIDEOS_PER_EPOCH
		# self.length = videos_per_epoch if videos_per_epoch > 0 else self.length
		# self.length *= cfg.TRAIN.EPOCH

		self.transform = transform
		self.target_transform = target_transform

	def __getitem__(self, index):
		HF = W  = wf = wf_h = self.wf_l = PL = PH = np.array([-1])
		env = self.env
		with env.begin(write=False) as txn:
			byteflow = txn.get(self.keys[index%self.length])
		unpacked = pa.deserialize(byteflow)
		# gene_higher_pilot
		if 'HF' in cfg.TRAIN.LABEL:
			HF = unpacked[2]
		if 'W' in cfg.TRAIN.LABEL:
			W = unpacked[3]
		if 'PH' in cfg.TRAIN.LABEL:
			PH = unpacked[0]
			if cfg.CEST.ENHANCEIN:
				PH =gene_higher_pilot(PH[np.newaxis,:]).squeeze(0)
		if 'PL' in cfg.TRAIN.LABEL:
			PL = unpacked[1]
			if cfg.CEST.ENHANCEIN:
				PL =gene_higher_pilot(PL[np.newaxis,:]).squeeze(0)
		
		wf_h= wf_l = W
		# ph,pl,hf,w, wf_h, wf_l
		return PH, PL, HF, W, wf_h, wf_l

	def __len__(self):
		# return self.length
		return cfg.DATASET.VIDEOS_PER_EPOCH

	def __repr__(self):
		return self.__class__.__name__ + ' (' + self.db_path + ')'


def raw_reader(path):
	with open(path, 'rb') as f:
		bin_data = f.read()
	return bin_data


def dumps_pyarrow(obj):
	"""
	Serialize an object.
	Returns:
		Implementation-dependent bytes-like object
	"""
	return pa.serialize(obj).to_buffer()


def folder2lmdb(hf_path, pilot_h_path, pilot_l_path, w_path, outpath, write_frequency=5000):
	hf = np.load(hf_path)['data']
	hf = np.expand_dims(hf, axis=1)
	hf = np.concatenate([np.real(hf), np.imag(hf)], 1)
	# hf = hf[:10000]

	# load pilot
	pilot_h = np.load(pilot_h_path)['data']
	pilot_h = np.expand_dims(pilot_h, axis=1)
	pilot_h = np.concatenate([np.real(pilot_h), np.imag(pilot_h)], 1)
	pilot_l = np.load(pilot_l_path)['data']
	pilot_l = np.expand_dims(pilot_l, axis=1)
	pilot_l = np.concatenate([np.real(pilot_l), np.imag(pilot_l)], 1)
	# pilot_h = pilot_h[:10000]
	# load eigenvector
	w = np.load(w_path)['data']
	w = np.expand_dims(w, axis=1)
	w = np.concatenate([np.real(w), np.imag(w)], 1)
	# w = w[:10000]
	# hf, pilot, w = hf[:10000], pilot[:10000], w[:10000]

	split_idx = int(0.98 * pilot_h.shape[0])
	pilot_h_train, pilot_h_val = pilot_h[:split_idx,...], pilot_h[split_idx:,...]
	pilot_l_train, pilot_l_val = pilot_l[:split_idx,...], pilot_l[split_idx:,...]
	hf_train, hf_val = hf[:split_idx,...], hf[split_idx:,...]
	w_train, w_val = w[:split_idx,...], w[split_idx:,...]
	# Train
	train_output = os.path.join(outpath,'train')
	dataset_train = DatasetFolder(pilot_h_train, pilot_l_train, hf_train, w_train)
	train_data_loader = DataLoader(dataset_train, num_workers=16, collate_fn=lambda x: x)
	train_lmdb_path = os.path.expanduser(train_output)
	print("Generate LMDB to %s" % train_lmdb_path)
	train_db = lmdb.open(train_lmdb_path, subdir=os.path.isdir(train_lmdb_path),
				   map_size=1099511627776 * 2, readonly=False,
				   meminit=False, map_async=True)

	txn = train_db.begin(write=True)
	for idx, data in enumerate(train_data_loader):
		p_h, p_l, label_hf, label_w = data[0]
		txn.put(u'{}'.format(idx).encode('ascii'), dumps_pyarrow((p_h, p_l, label_hf,label_w)))
		if idx % write_frequency == 0:
			print("[%d/%d]" % (idx, len(train_data_loader)))
			txn.commit()
			txn = train_db.begin(write=True)
	# finish iterating through dataset
	txn.commit()
	keys = [u'{}'.format(k).encode('ascii') for k in range(idx + 1)]
	with train_db.begin(write=True) as txn:
		txn.put(b'__keys__', dumps_pyarrow(keys))
		txn.put(b'__len__', dumps_pyarrow(len(keys)))
	train_db.sync()
	train_db.close()
	print("Flushing train database ...")
	# Val
	val_output = os.path.join(outpath,'val')
	val_dataset = DatasetFolder(pilot_h_val, pilot_l_val, hf_val, w_val)
	val_data_loader = DataLoader(val_dataset, num_workers=16, collate_fn=lambda x: x)
	val_lmdb_path = os.path.expanduser(val_output)
	print("Generate LMDB to %s" % val_lmdb_path)
	val_db = lmdb.open(val_lmdb_path, subdir=os.path.isdir(val_lmdb_path),
				   map_size=1099511627776 * 2, readonly=False,
				   meminit=False, map_async=True)

	txn = val_db.begin(write=True)
	for idx, data in enumerate(val_data_loader):
		p_h, p_l, label_hf, label_w = data[0]
		txn.put(u'{}'.format(idx).encode('ascii'), dumps_pyarrow((p_h, p_l, label_hf,label_w)))
		if idx % write_frequency == 0:
			print("[%d/%d]" % (idx, len(val_data_loader)))
			txn.commit()
			txn = val_db.begin(write=True)
	# finish iterating through dataset
	txn.commit()
	keys = [u'{}'.format(k).encode('ascii') for k in range(idx + 1)]
	with val_db.begin(write=True) as txn:
		txn.put(b'__keys__', dumps_pyarrow(keys))
		txn.put(b'__len__', dumps_pyarrow(len(keys)))
	val_db.sync()
	val_db.close()
	print("Flushing val database ...")

if __name__ == "__main__":
	parser = argparse.ArgumentParser()
	parser.add_argument("--hf", default="Data/hf.npz",help="Path to original image dataset folder")
	parser.add_argument("--pilot_h", default="Data/pilot_1.npz",help="Path to original image dataset folder")
	parser.add_argument("--pilot_l", default="Data/pilot_2.npz",help="Path to original image dataset folder")
	parser.add_argument("--w", default="Data/w.npz",help="Path to original image dataset folder")
	parser.add_argument("--outpath", default="waic",help="Path to output LMDB file")
	args = parser.parse_args()
	folder2lmdb(args.hf, args.pilot_h, args.pilot_l, args.w, args.outpath)