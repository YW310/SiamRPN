import argparse
import os
import random
import shutil
import time
import warnings

import torch
import torch.nn as nn
import torch.nn.parallel
import torch.backends.cudnn as cudnn
import torch.distributed as dist
import torch.optim
import torch.multiprocessing as mp
import torch.utils.data
import torch.utils.data.distributed
import torchvision.transforms as transforms
import torchvision.datasets as datasets
import torchvision.models as models

model_names = sorted(name for name in models.__dict__
    if name.islower() and not name.startswith("__")
    and callable(models.__dict__[name]))

best_acc1 = 0


def main(args):
    # Data loading code
    if args.lmdb:
        from utils import pro_lmdb
        image_folder = pro_lmdb.ImageFolderLMDB
        db_path = 'waic'
    else:
        image_folder = datasets.ImageFolder
        db_path=None

    train_dataset = image_folder(db_path,transform=None)
    if False:
        train_sampler = torch.utils.data.distributed.DistributedSampler(train_dataset)
    else:
        train_sampler = None

    train_loader = torch.utils.data.DataLoader(
        train_dataset, batch_size=16, shuffle=(train_sampler is None),
        num_workers=1, pin_memory=True, sampler=train_sampler)

    for i,(pilot, hf) in enumerate(train_loader):
        print(i,pilot.shape,hf.shape)
        pass


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Test LMDB file')
    parser.add_argument('--lmdb',action="store_true", help='Using LMDB format instead of raw images')
    args = parser.parse_args() 
    main(args)