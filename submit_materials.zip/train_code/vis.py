import argparse
import logging
import os
import time
import json
import random
import math
import numpy as np
import torch
import torch.nn as nn
from utils import pro_lmdb
from utils.config import cfg

from models.model_builder import ModelBuilder
from tensorboardX import SummaryWriter


logger = logging.getLogger('global')

def cal_eigenvector(channel):
	"""
		Description:
			calculate the eigenvector on each subband
		Input:
			channel: np.array, channel in frequency domain,  shape [batch_size, rx_num, tx_num, subcarrier_num]
		Output:
			eigenvectors:  np.array, eigenvector for each subband, shape [batch_size, tx_num, subband_num]
	"""
	subband_num = 13
	hf_ = np.transpose(channel, [0,3,1,2]) # (batch,subcarrier_num,4,32)
	hf_h = np.conj(np.transpose(channel, [0,3,2,1])) # (batch,subcarrier_num,32,4)
	R = np.matmul(hf_h, hf_) # (batch,subcarrier_num,32,32)
	R = R.reshape(R.shape[0],subband_num,-1,R.shape[2],R.shape[3]).mean(axis=2) # average the R over each subband, (batch,13,32,32)
	[D,V] = np.linalg.eig(R)
	v = V[:,:,:,0]
	eigenvectors = np.transpose(v,[0,2,1])
	return eigenvectors

def cos_sim(vector_a, vector_b):
	vector_a = np.mat(vector_a)
	vector_b = np.mat(vector_b)
	num = vector_a * vector_b.H
	num1 = np.sqrt(vector_a * vector_a.H)
	num2 = np.sqrt(vector_b * vector_b.H)
	cos = (num / (num1*num2))
	return cos.item()

def cal_score(w_true,w_pre):
	NUM_TX = 32
	NUM_SUBBAND = 13
	BS = w_true.shape[0]
	w_true = np.transpose(w_true, [0, 3, 2, 1])
	w_pre = np.transpose(w_pre, [0, 3, 2, 1])
	img_total = NUM_TX * 2
	num_sample_subband = BS*NUM_SUBBAND #NUM_SAMPLES * NUM_SUBBAND
	W_true = np.reshape(w_true, [num_sample_subband, img_total])
	W_pre = np.reshape(w_pre, [num_sample_subband, img_total])
	W_true2 = W_true[0:num_sample_subband, 0:int(img_total):2] + 1j*W_true[0:num_sample_subband, 1:int(img_total):2]
	W_pre2 = W_pre[0:num_sample_subband, 0:int(img_total):2] + 1j*W_pre[0:num_sample_subband, 1:int(img_total):2]
	score_cos = 0
	for i in range(num_sample_subband):
		W_true2_sample = W_true2[i:i+1,]
		W_pre2_sample = W_pre2[i:i+1,]
		score_tmp = cos_sim(W_true2_sample,W_pre2_sample)
		score_cos = score_cos + abs(score_tmp)*abs(score_tmp)
	score_cos = score_cos/num_sample_subband
	return score_cos

def seed_torch(seed=0):
	random.seed(seed)
	os.environ['PYTHONHASHSEED'] = str(seed)
	np.random.seed(seed)
	torch.manual_seed(seed)
	torch.cuda.manual_seed(seed)
	torch.backends.cudnn.benchmark = True
	torch.backends.cudnn.deterministic = True

def build_val_loader():
	if cfg.VALSET.VALSET == False:
		return None
	logger.info("build val dataset")
	if cfg.VALSET.LMDB:
		val_dataset = pro_lmdb.ImageFolderLMDB(cfg.VALSET.WAIC.ROOT,transform=None)
	else:
		val_dataset = pro_lmdb.DatasetVal()

	logger.info("build val done")
	val_loader = torch.utils.data.DataLoader(val_dataset,
							  batch_size=512,num_workers=4,
							  pin_memory=True,sampler=None,persistent_workers=True)
	return val_loader


def main(args):
	cfg.merge_from_file(args.config)
	model = ModelBuilder().cuda().train()
	model.load_state_dict(torch.load(args.model_path)['state_dict'],strict=False)
	val_loader = build_val_loader()
	test(args, val_loader, model)

def test(args, val_loader, model):
	end = time.time()
	model.zero_grad()
	with torch.no_grad(): 
		loss_val = 0.0
		score_val = 0.0
		TTANUM = 1
		for idx_val, (pilot_h_val, pilot_l_val, hf_val, w_val, wf_h_val, wf_l_val) in enumerate(val_loader):
			best_score = 0.0
			best_wf_p = None
			outputs_val = None
			if idx_val%10 == 0:
				print(idx_val)
			for n in range(1,TTANUM+1):
				if n>=TTANUM:
					if idx_val == 0:
						w_val_arr = w_val.cpu().numpy()
					else:
						w_val_arr = np.concatenate((w_val_arr, w_val.cpu().numpy()), axis=0)
				if cfg.CEST.KWARGS.input_length == 208:
					outputs_val = model(pilot_h_val, hf_val, w_val, wf_h_val, train_flag=False)
				elif cfg.CEST.KWARGS.input_length == 48:
					outputs_val = model(pilot_l_val, hf_val, w_val, wf_l_val, train_flag=False)
				else:
					NotImplementedError
				if cfg.TRAIN.TRAIN == 'enc':
					hf_p_val = outputs_val['hf_p']
					# step 2: eigenvector calculation
					h_complex = hf_p_val[:,0,...] + 1j*hf_p_val[:,1,...] # (batch,4,32,52)
					v = cal_eigenvector(h_complex.cpu().numpy())
					# step 3: eigenvector compression
					w_complex = torch.from_numpy(v)
					w = torch.zeros([hf_p_val.shape[0], 2, 32, 13], dtype=torch.float32).cuda() # (batch,2,32,13)
					w[:,0,:,:] = torch.real(w_complex)
					w[:,1,:,:] = torch.imag(w_complex)
					wf_p = w.cpu().numpy()
					if idx_val == 0:
						wf_p_arr = wf_p
					else:
						wf_p_arr = np.concatenate((wf_p_arr, wf_p), axis=0)
				elif cfg.TRAIN.TRAIN == 'dec':

					wf_p = outputs_val['wf_p']
					score = cal_score(wf_h_val.cpu().numpy(), wf_p.cpu().numpy())
					if best_score < score:
						best_score = score
						best_wf_p = wf_p
					wf_p = best_wf_p
					if n>=TTANUM:
						if idx_val == 0:
							wf_p_arr = wf_p.cpu().numpy()
						else:
							wf_p_arr = np.concatenate((wf_p_arr, wf_p.cpu().numpy()), axis=0)
				elif cfg.TRAIN.TRAIN == 'dec_wo_cest':
					wf_p = outputs_val['wf_p']
					# score_val += cal_score(w_val,wf_p.cpu().numpy())
					if idx_val == 0:
						wf_p_arr = wf_p.cpu().numpy()
					else:
						wf_p_arr = np.concatenate((wf_p_arr, wf_p.cpu().numpy()), axis=0)
				else:
					NotImplementedError
			loss_val += outputs_val['total_loss'].item()
			# break
		# cal loss on validation set
		loss_val = loss_val/(idx_val+1)
		score_val = cal_score(w_val_arr, wf_p_arr)	
		logger.info('loss_val:{}\nscore_val:{},\n'.format(loss_val,score_val))
		print('loss_val:{}\nscore_val:{},\n'.format(loss_val,score_val)) # 0.7278967199853111

if __name__ == '__main__':
	parser = argparse.ArgumentParser(description='Test LMDB file')
	parser.add_argument('--config', type=str, default='/data/project/transwaic/exp/decvq/config_g_p0.10_woln.yaml',help='configuration of tracking')
	parser.add_argument("--model_path", default='/data/project/transwaic/exp/decvq/snapshot_g/checkpoint_e108.pth',help='model path')
	args = parser.parse_args()
	seed_torch(123456)
	main(args)