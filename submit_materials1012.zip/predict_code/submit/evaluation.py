#=======================================================================================================================
#=======================================================================================================================
# Package Importing
import sys
import os
import numpy as np
from modelDesign import encFunction_1, encFunction_2, decFunction_1, decFunction_2
# from modelDesign_xy import encFunction_1, encFunction_2, decFunction_1, decFunction_2

#=======================================================================================================================
#=======================================================================================================================
# Parameters Setting
NUM_SAMPLES = 6000
NUM_FEEDBACK_BITS = 64
NUM_RX = 4
NUM_TX = 32
NUM_SUBBAND = 13
#=======================================================================================================================
#=======================================================================================================================
# Data Loading
# Data 1 Loading
# output_path = 'submit/modelSubmit_xy'
pilot_1 = np.load('Data/pilot_1.npz')['data']
length = pilot_1.shape[0]
split_idx = int(0.98 * length)
pilot_1 = pilot_1[split_idx:,...]
pilot_1 = np.expand_dims(pilot_1, axis=1)
pilot_1 = np.concatenate([np.real(pilot_1), np.imag(pilot_1)], 1) # shape: sample, 2, 4, 208, 4
w_1 =  np.load('Data/w.npz')['data']
w_1 = w_1[split_idx:,...]
w_1 = np.expand_dims(w_1, axis=1)
w_1 = np.concatenate([np.real(w_1), np.imag(w_1)], 1) # shape: sample, 2, 32, 13
# Data 2 Loading
pilot_2 = np.load('Data/pilot_2.npz')['data']
pilot_2 = pilot_2[split_idx:,...]
pilot_2 = np.expand_dims(pilot_2, axis=1)
pilot_2 = np.concatenate([np.real(pilot_2), np.imag(pilot_2)], 1) # shape: sample, 2, 4, 48, 4
# w_2 = np.load('Data/w.npz')['data']
# w_2 = np.expand_dims(w_2, axis=1)
# w_2 = np.concatenate([np.real(w_2), np.imag(w_2)], 1)
w_2 = w_1
#=======================================================================================================================
#=======================================================================================================================
# Encoding
# Data 1 Encoding
encOutput_1 = encFunction_1(pilot_1, './modelSubmit/encModel_p1_1.pth.tar', './modelSubmit/encModel_p1_2.pth.tar') # The shape of the function output should be (NUM_SAMPLES, NUM_FEEDBACK_BITS), and each element should be a binary number
# Data 2 Encoding
encOutput_2 = encFunction_2(pilot_2, './modelSubmit/encModel_p2_1.pth.tar', './modelSubmit/encModel_p2_2.pth.tar') # The shape of the function output should be (NUM_SAMPLES, NUM_FEEDBACK_BITS), and each element should be a binary number
#=======================================================================================================================
#=======================================================================================================================
# Encoder Output Checking
if encOutput_1.ndim != 2 or encOutput_2.ndim != 2:
    print("Invalid dimension of feedback bits sequence")
    sys.exit()
elif (np.shape(encOutput_1) == np.array([NUM_SAMPLES, NUM_FEEDBACK_BITS])).all() == False or (np.shape(encOutput_2) == np.array([NUM_SAMPLES, NUM_FEEDBACK_BITS])).all() == False:
    print("Invalid shape of feedback bits sequence")
    sys.exit()
elif np.any(np.multiply(encOutput_1, encOutput_1) != encOutput_1) or  np.any(np.multiply(encOutput_2, encOutput_2) != encOutput_2):
    print("Invalid form of feedback bits sequence")
    sys.exit()
else:
    pass
#=======================================================================================================================
#=======================================================================================================================
# Decoding
# Data 1 Decoding
w_pre_1 = decFunction_1(encOutput_1, 'modelSubmit/decModel_p1_1.pth.tar', './modelSubmit_vit_ei/decModel_p1_2.pth.tar') # The shape of the function output should be (NUM_SAMPLES, 2, NUM_TX, NUM_SUBBAND)
# Data 2 Decoding
w_pre_2 = decFunction_2(encOutput_2, 'modelSubmit/decModel_p2_1.pth.tar', './modelSubmit_vit_ei/decModel_p2_2.pth.tar') # The shape of the function output should be (NUM_SAMPLES, 2, NUM_TX, NUM_SUBBAND)
#=======================================================================================================================
#=======================================================================================================================
# Decoder Output Checking
if w_pre_1.ndim != 4 or w_pre_2.ndim != 4:
    print("Invalid dimension of final output")
    sys.exit()
elif (np.shape(w_pre_1) == np.array([NUM_SAMPLES, 2, NUM_TX, NUM_SUBBAND])).all() == False or (np.shape(w_pre_2) == np.array([NUM_SAMPLES, 2, NUM_TX, NUM_SUBBAND])).all() == False:
    print("Invalid shape of feedback bits sequence")
    sys.exit()
else:
    pass
# =======================================================================================================================
# =======================================================================================================================
# Score Calculating
def cos_sim(vector_a, vector_b):
    vector_a = np.mat(vector_a)
    vector_b = np.mat(vector_b)
    num = vector_a * vector_b.H
    num1 = np.sqrt(vector_a * vector_a.H)
    num2 = np.sqrt(vector_b * vector_b.H)
    cos = (num / (num1*num2))
    return cos.item()

def cal_score(w_true,w_pre):
    w_true = np.transpose(w_true, [0, 3, 2, 1])
    w_pre = np.transpose(w_pre, [0, 3, 2, 1])
    img_total = NUM_TX * 2
    num_sample_subband = NUM_SAMPLES * NUM_SUBBAND
    W_true = np.reshape(w_true, [num_sample_subband, img_total])
    W_pre = np.reshape(w_pre, [num_sample_subband, img_total])
    W_true2 = W_true[0:num_sample_subband, 0:int(img_total):2] + 1j*W_true[0:num_sample_subband, 1:int(img_total):2]
    W_pre2 = W_pre[0:num_sample_subband, 0:int(img_total):2] + 1j*W_pre[0:num_sample_subband, 1:int(img_total):2]
    score_cos = 0
    for i in range(num_sample_subband):
        W_true2_sample = W_true2[i:i+1,]
        W_pre2_sample = W_pre2[i:i+1,]
        score_tmp = cos_sim(W_true2_sample,W_pre2_sample)
        score_cos = score_cos + abs(score_tmp)*abs(score_tmp)
    score_cos = score_cos/num_sample_subband
    return score_cos
score1 = cal_score(w_1, w_pre_1)
score2 = cal_score(w_2, w_pre_2)
score = (score1 + score2) / 2
print('The score 1 is ' + str(score1))
print('The score 2 is ' + str(score2))
print('The final score is ' + str(score))
print('Finished!')