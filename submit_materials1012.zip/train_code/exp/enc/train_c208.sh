source ~/.bashrc
cd /data/project/transwaic_c/exp/enc/
echo 'start s0 training stage'
python -m torch.distributed.launch --nproc_per_node=2 --master_port=2337 ../../train.py --config 'config_c208_s0.yaml'
echo 'start s1 training stage'
python -m torch.distributed.launch --nproc_per_node=2 --master_port=2337 ../../train.py --config 'config_c208_s1.yaml'