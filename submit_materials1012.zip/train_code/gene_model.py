# Package Importing
import sys
import numpy as np
import torch
from torch import nn
from torch.utils.data import Dataset
import tqdm
from utils.config import cfg
import random
import os
import argparse
from utils.config import cfg
from models.model_builder import ModelBuilder
import logging

logger = logging.getLogger('global')

def remove_prefix_swin(state_dict, prefix):
	logger.info('swin style: remove prefix \'{}\''.format(prefix))
	# f = lambda x: x.split(prefix, 1)[-1] if x.startswith(prefix) else x
	return {key: value for key, value in state_dict[prefix].items()}


def remove_prefix(state_dict, prefix):
	''' Old style model is stored with all names of parameters
	share common prefix 'module.' '''
	logger.info('remove prefix \'{}\''.format(prefix))
	f = lambda x: x.split(prefix, 1)[-1] if x.startswith(prefix) else x
	return {f(key): value for key, value in state_dict.items()}

def load_pretrain(model, pretrained_path, backbone = False,del_prev=False):
	if os.path.isfile(pretrained_path)==False:
		print("Not Found Model")
		return model
	logger.info('load pretrained model from {}'.format(pretrained_path))
	device = torch.cuda.current_device()
	pretrained_dict = torch.load(pretrained_path,
		map_location=lambda storage, loc: storage.cuda(device))
	if "model" in pretrained_dict.keys():
		pretrained_dict = remove_prefix_swin(pretrained_dict,
										'model')
	elif "state_dict" in pretrained_dict.keys():
		pretrained_dict = remove_prefix(pretrained_dict['state_dict'],
										'module.')
	else:
		pretrained_dict = remove_prefix(pretrained_dict, 'module.')
	model.load_state_dict(pretrained_dict, strict=False)
	return model


def main(args):
	cfg.merge_from_file(args.config)
	if cfg.CEST.KWARGS.input_length == 208 or cfg.CEST.KWARGS.input_length == 416:
		type_p = 1  
	else:
		type_p =2 
	
	model = ModelBuilder(cest=True).cuda().eval()
	print('gene enc model..')
	if cfg.TRAIN.PRETRAINED != '':
		model = load_pretrain(model, cfg.TRAIN.PRETRAINED)
		print('whole-model loaded: ',cfg.TRAIN.PRETRAINED )
	if cfg.CEST.PRETRAINED != '':
		model = load_pretrain(model, cfg.CEST.PRETRAINED)
		print('cest-model loaded: ',cfg.CEST.PRETRAINED )
	torch.save({'state_dict':model.state_dict(),},
		args.output_path+'/encModel_p%d_1.pth.tar' % (type_p))

	model = ModelBuilder(cest=False).cuda().eval()
	if cfg.TRAIN.PRETRAINED != '':
		model = load_pretrain(model, cfg.TRAIN.PRETRAINED)
		print('whole-model loaded: ',cfg.TRAIN.PRETRAINED )
	torch.save({'state_dict':model.state_dict(),},
		args.output_path+'/decModel_p%d_1.pth.tar' % (type_p))

if __name__ == '__main__':
	parser = argparse.ArgumentParser(description='Test LMDB file')
	parser.add_argument('--config', type=str, default='exp/joint/config_c48.yaml',help='configuration of tracking')
	parser.add_argument("--output_path", default='user_data',help='model path')
	args = parser.parse_args()
	main(args)