gene_model.py --config 'exp/joint/config_c48.yaml' --output_path 'user_data'
gene_model.py --config 'exp/joint/config_c208.yaml' --output_path 'user_data'
