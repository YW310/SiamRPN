'''
The content of this file could be self-defined. 
But please note the interface of the following function cannot be modified,
	- encFunction_1
	- decFunction_1
	- encFunction_2
	- decFunction_2
'''
#=======================================================================================================================
#=======================================================================================================================
# Package Importing
import math
import torch
from torch import nn
from einops import rearrange
import torch.nn.functional as F
from torch import Tensor
from einops.layers.torch import Rearrange
from timm.models.layers import trunc_normal_, DropPath


class FeedForward(nn.Module):
	def __init__(self, dim, hidden_dim, dropout = 0., csi=False):
		super().__init__()
		if csi:
			self.net = nn.Sequential(
			nn.LayerNorm(dim),
			nn.Linear(dim, hidden_dim),
			nn.GELU(),
			nn.Linear(hidden_dim, dim),
			)
		else:
			self.net = nn.Sequential(
				nn.Linear(dim, hidden_dim),
				nn.GELU(),
				nn.Dropout(dropout),
				nn.Linear(hidden_dim, dim),
				nn.Dropout(dropout)
			)
		
	def forward(self, x):
		return self.net(x)


class Attention(nn.Module):
	def __init__(self, dim, heads = 8, dim_head = 64):
		super().__init__()
		inner_dim = dim_head *  heads
		self.heads = heads
		self.scale = dim_head ** -0.5
		self.norm = nn.LayerNorm(dim)

		self.attend = nn.Softmax(dim = -1)

		self.to_qkv = nn.Linear(dim, inner_dim * 3, bias = False)
		self.to_out = nn.Linear(inner_dim, dim, bias = False)

	def forward(self, x):
		x = self.norm(x)

		qkv = self.to_qkv(x).chunk(3, dim = -1)
		q, k, v = map(lambda t: rearrange(t, 'b n (h d) -> b h n d', h = self.heads), qkv)

		dots = torch.matmul(q, k.transpose(-1, -2)) * self.scale

		attn = self.attend(dots)

		out = torch.matmul(attn, v)
		out = rearrange(out, 'b h n d -> b n (h d)')
		return self.to_out(out)

class Transformer(nn.Module):
	def __init__(self, dim, depth, heads, dim_head, mlp_dim,dropout=0.0):
		super().__init__()
		self.layers = nn.ModuleList([])
		for _ in range(depth):
			self.layers.append(nn.ModuleList([
				Attention(dim, heads = heads, dim_head = dim_head),
				FeedForward(dim, mlp_dim,csi=True)
			]))
	def forward(self, x):
		for attn, ff in self.layers:
			x = attn(x) + x
			x = ff(x) + x
		return x


def gumbel_sigmoid(logits: Tensor, tau: float = 0.5, hard: bool = False, threshold: float = 0.5, gumbel_noise=1.0) -> Tensor:
	gumbels = (
		-torch.empty_like(logits, memory_format=torch.legacy_contiguous_format).exponential_().log()
	)*gumbel_noise  # ~Gumbel(0, 1)
	gumbels = (logits + gumbels) / tau  # ~Gumbel(logits, tau)
	y_soft = gumbels.sigmoid()
	if hard:
		# y_soft = logits.sigmoid()
		# Straight through.
		indices = (y_soft > threshold).nonzero(as_tuple=True)
		y_hard = torch.zeros_like(logits, memory_format=torch.legacy_contiguous_format)
		y_hard[indices[0], indices[1]] = 1.0
		ret = y_hard - y_soft.detach() + y_soft
	else:
		# Reparametrization trick.
		ret = y_soft
	return ret

def pair(t):
	return t if isinstance(t, tuple) else (t, t)

class SimpleViT(nn.Module):
	def __init__(self, dim, depth, heads=4, mlp_dim=2048, in_channels = 2, dim_head = 64, dropout=0.0, arrange = False):
		super().__init__()
		self.to_patch_embedding = nn.Sequential(
			nn.Conv2d(in_channels, dim, (6, 6), (3, 3)),
			Rearrange('b c h w -> (h w) b c'),
			nn.Linear(dim, dim),
		)
		self.pos_encoder = PositionalEncoding(dim, 0.0)
		self.transformer = Transformer(dim, depth, heads, dim_head, mlp_dim, dropout=dropout)
		self.arrange = arrange

	def forward(self, img):
		if self.arrange:
			img = rearrange(img, 'b c (x y h) w ->b c (x h y) w', x=2, y=2)
		
		x = self.to_patch_embedding(img)
		x = self.pos_encoder(x)
		x = rearrange(x, 'n b c -> b n c')
		x = self.transformer(x)
		return x

class Encoder(nn.Module):
	B = 2
	def __init__(self, feedback_bits, quantization=True,d_model=384,nhead=3,d_hid=384,dropout=0.0,nlayers=6, balance_sig=False, quantization_type='org', batch_first=False, tau=0.5, tta=False, tta_num=5, inference=False, gumbel_noise=1.0, arrange=False):
		super(Encoder, self).__init__()
		self.transformer_encoder = SimpleViT(dim=d_model, depth=nlayers, heads=nhead, mlp_dim=d_hid, in_channels = 2, dim_head = d_model//nhead, dropout=dropout, arrange=arrange)
		self.fc1 = nn.Linear(64, d_model)
		self.balance_sig = balance_sig
		self.batch_first = batch_first
		if balance_sig:
			self.fc_b = nn.Linear(27*d_model, int(feedback_bits))
		else:
			self.fc2 = nn.Linear(27*d_model, int(feedback_bits / self.B))
			self.sig = nn.Sigmoid()
		self.quantization = quantization
		self.tau = tau
		self.tta = tta
		self.tta_num = tta_num
		self.inference = inference
		self.gumbel_noise = gumbel_noise
	
	def set_inference(self, flag=False):
		self.inference = flag
	
	def forward(self, x): # (batch, 2, 32, 13), b c eig f
		en_out = self.transformer_encoder(x)
		out = rearrange(en_out, 'b n f -> b (n f)')
		if self.balance_sig:
			out = self.fc_b(out)
			if self.tta:
				out = torch.stack([gumbel_sigmoid(out,hard = self.inference, tau=self.tau) for x in range(1,self.tta_num+1)]).cuda()
				# out = out.transpose(0,1).contiguous()
				out = out.view(-1,64)
			else:
				out = gumbel_sigmoid(out,hard = self.inference, tau=self.tau, gumbel_noise = self.gumbel_noise)
			# out = hardisg(out,lamda=10.0)
			# out = out[:,:32]*(2.0/3.0) + out[:,32:]*(1.0/3.0)
		else:
			out = self.fc2(out) # (batch, 512/B)
			out = self.sig(out)
		
		if self.quantization:
			out = self.quantize(out)
		else:
			out = out
		return out, en_out
class Decoder(nn.Module):
	B = 2
	def __init__(self, feedback_bits, quantization=True,d_model=384,nhead=3,d_hid=384,dropout=0.0,
			nlayers=6, balance_sig=False, quantization_type='org', batch_first=False, cnn=False, codeformer=False):
		super(Decoder, self).__init__()
		self.pos_encoder = PositionalEncoding(d_model, dropout)
		self.pos_encoder_bits = PositionalEncodingBits(1)
		decoder_layers = nn.TransformerEncoderLayer(d_model, nhead, d_hid, dropout)
		self.transformer_decoder = nn.TransformerEncoder(decoder_layers, nlayers)
		# decoder_layers = nn.TransformerEncoderLayer(d_model, nhead, d_hid, dropout)
		# self.sig = nn.Sigmoid()
		self.feedback_bits = feedback_bits
		self.batch_first = batch_first
		self.balance_sig = balance_sig
		self.cnn = cnn
		self.codeformer = codeformer
		if balance_sig: #B, bit
			if self.cnn:
				self.conv_fuse = nn.Sequential(
					nn.Conv1d(1, 512, kernel_size=3, stride=1, padding=1, bias=True),
					nn.Conv1d(512, 1, kernel_size=3, stride=1, padding=1, bias=True))
			if self.codeformer:
				self.codeformer_conv1 = nn.Sequential(
					nn.Conv1d(1, 16, kernel_size=3, stride=1, padding=1, bias=True))
				self.codeformer_proc = nn.TransformerEncoder( nn.TransformerEncoderLayer(16, 4, 32, dropout = 0.0), 2)
				self.fc_a = nn.Linear(16, 1)
			self.fc_b = nn.Linear(int(feedback_bits), 13*d_model)
		else:
			self.fc1 = nn.Linear(int(feedback_bits / self.B), 13*d_model)
		self.fc2 = nn.Linear(d_model, 32*2)
	
	def forward(self, x):
		out = x
		if self.balance_sig:
			out = self.pos_encoder_bits(out)
			if self.cnn:
				out = self.conv_fuse(out.unsqueeze(1)).squeeze(1)
			if self.codeformer:
				out = self.codeformer_conv1(out.unsqueeze(1)).transpose(1,2)
				out = rearrange(out, 'b n f -> n b f')
				out = self.codeformer_proc(out).squeeze(1)
				out = rearrange(out, 'n b f-> b n f')
				out = self.fc_a(out).squeeze(2)
			# out = self.conv_fuse(out.unsqueeze(1)).squeeze(1)
			out = self.fc_b(out)
		else:
			out = self.fc1(out) # (batch, 13*d_model)
		out = rearrange(out, 'b (f dmodel) -> f b dmodel', f=13)
		out = self.pos_encoder(out)
		if self.batch_first:
			out = rearrange(out, 's b f -> b s f', s=13)
		out = self.transformer_decoder(out) # (13, batch, d_model)
		if self.batch_first:
			out = rearrange(out, 'b s f -> s b f', s=13)
		out = self.fc2(out) # (13, batch, 32*2)
		out = rearrange(out, 'f b (c eig) -> b c eig f', c=2)
		return out
	
class PositionalEncoding(nn.Module):
	def __init__(self, d_model: int, dropout: float = 0.1, max_len: int = 128):
		super().__init__()
		position = torch.arange(max_len).unsqueeze(1)
		div_term = torch.exp(torch.arange(0, d_model, 2) * (-math.log(10000.0) / d_model))
		pe = torch.zeros(max_len, 1, d_model)
		pe[:, 0, 0::2] = torch.sin(position * div_term)
		pe[:, 0, 1::2] = torch.cos(position * div_term)
		self.register_buffer('pe', pe)
	def forward(self, x):
		"""
		Args:
			x: Tensor, shape [seq_len, batch_size, embedding_dim]
		"""
		x = x + self.pe[:x.size(0)]
		return x

class PositionalEncodingBits(nn.Module):
	def __init__(self, d_model: int, dropout: float = 0.1, max_len: int = 128):
		super().__init__()
		#self.dropout = nn.Dropout(p=dropout)
		position = torch.arange(max_len).unsqueeze(1)
		div_term = torch.exp(torch.arange(0, d_model, 2) * (-math.log(10000.0) / d_model))
		pe = torch.zeros(max_len, d_model)
		pe[:, 0::2] = torch.sin(position * div_term)
		pe[:, 1::2] = torch.cos(position * div_term)
		self.pe = pe.cuda()
	def forward(self, x):
		"""
		Args:
			x: Tensor, shape [seq_len, batch_size, embedding_dim]
		"""
		x = x + self.pe[1:x.size(1)+1].squeeze().unsqueeze(0)
		return x

class VITAE(nn.Module):
	def __init__(self, feedback_bits,quantization=True,d_model=384,nhead=3,d_hid=384,dropout=0.0,en_nlayers=6, de_nlayers=6, LN=False, balance_sig=False, 
			quantization_type='org', batch_first=False,tau=0.5,tta=False, tta_num=5, inference=False, cnn=False, codeformer = False, gumbel_noise=1.0, arrange=False):
		super(VITAE, self).__init__()
		self.encoder = Encoder(feedback_bits,quantization, d_model, nhead, d_hid, dropout, en_nlayers, balance_sig, quantization_type=quantization_type, batch_first=batch_first,tau=tau,tta=tta,tta_num = tta_num, inference=inference, arrange=arrange)
		self.decoder = Decoder(feedback_bits,quantization, d_model, nhead, d_hid, dropout, de_nlayers, balance_sig, quantization_type=quantization_type, batch_first=batch_first, cnn=cnn, codeformer = codeformer)
		self.LN = LN
		self.tta = tta
		self.tta_num = tta_num
		self.apply(self._init_weights)

	def norminput(self,x):
		x = x.permute(0, 3, 2, 1)
		bs, sc, ant, _ = x.shape
		x = x.reshape(bs*sc, ant, 2)
		x_re, x_im = x[..., 0], x[..., 1]
		v,_ = torch.max(x.view(bs*sc,-1),dim=1)
		v = v.unsqueeze(1).unsqueeze(1)
		x /= v
		x = x.view(bs, sc, ant, 2).permute(0, 3, 2, 1)

		return x

	def _init_weights(self, m):
		if isinstance(m, nn.Linear):
			trunc_normal_(m.weight, std=.02)
			if isinstance(m, nn.Linear) and m.bias is not None:
				nn.init.constant_(m.bias, 0)
		elif isinstance(m, nn.LayerNorm):
			nn.init.constant_(m.bias, 0)
			nn.init.constant_(m.weight, 1.0)   
			
	def set_inference(self, flag=False):
		self.encoder.set_inference(flag = flag)

	def cal_cossim(self,w_true,w_pre):
		eps = 1e-20
		w_true, w_pre = w_true.permute(0, 3, 2, 1), w_pre.permute(0, 3, 2, 1)
		num_batch, num_sc, num_ant = w_true.size(0), w_true.size(1), w_true.size(2)
		w_true = w_true.reshape(num_batch * num_sc, num_ant, 2)
		w_pre = w_pre.reshape(num_batch * num_sc, num_ant, 2)
		w_true_re, w_true_im = w_true[..., 0], w_true[..., 1]
		w_pre_re, w_pre_im = w_pre[..., 0], w_pre[..., 1]
		numerator_re = (w_true_re * w_pre_re + w_true_im * w_pre_im).sum(-1)
		numerator_im = (w_true_im * w_pre_re - w_true_re * w_pre_im).sum(-1)
		denominator_0 = (w_true_re ** 2 + w_true_im ** 2).sum(-1)
		denominator_1 = (w_pre_re ** 2 + w_pre_im ** 2).sum(-1)
		cos_similarity = torch.sqrt(numerator_re ** 2 + numerator_im ** 2) / (
					torch.sqrt(denominator_0) * torch.sqrt(denominator_1)+eps)
		cos_similarity = cos_similarity ** 2
		cos_similarity = cos_similarity.view(num_batch,num_sc).mean(1)
		return cos_similarity

	def forward(self, x):
		# if self.LN:
		# 	x = self.inln(x)
		BS = x.shape[0]
		if self.LN:
			x = self.norminput(x)
		feature, enout = self.encoder(x)
		if self.tta:
			with torch.no_grad():
				out = self.decoder(feature)
				score = self.cal_cossim(torch.stack([x for _ in range(1,self.tta_num+1)]).cuda().view(out.shape),out).view(self.tta_num,-1)
				best_idx = score.argmax(0)
				best_idx_2 = torch.arange(0,BS).long().cuda()
				feature = feature.view(self.tta_num,-1, 64)[best_idx,best_idx_2,:]
			
		out = self.decoder(feature)
		return out

def vit_ae(**kwargs):
	return VITAE(**kwargs)