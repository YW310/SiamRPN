import torch
import torch.nn as nn
from einops.layers.torch import Rearrange
from einops import rearrange

class FeedForward(nn.Module):
	def __init__(self, dim, hidden_dim, dropout = 0.):
		super().__init__()
		self.net = nn.Sequential(
			nn.Linear(dim, hidden_dim),
			nn.GELU(),
			nn.Dropout(dropout),
			nn.Linear(hidden_dim, dim),
			nn.Dropout(dropout)
		)
	def forward(self, x):
		return self.net(x)

class MDBlockS(nn.Module):
	def __init__(self, dim, num_patch, token_dim, channel_dim, dropout = 0., h =0, w=0):
		super().__init__()
		self.channel_mix = nn.Sequential(
			nn.LayerNorm(dim),
			FeedForward(dim, channel_dim, dropout),
		)
		self.w_mix = nn.Sequential(
			nn.LayerNorm(dim),
			Rearrange('b (h w) d -> b d h w', h=h),
			FeedForward(w, token_dim, dropout),
			Rearrange('b d h w -> b (h w) d', h=h),
		)
		self.h_mix = nn.Sequential(
			nn.LayerNorm(dim),
			Rearrange('b (h w) d -> b d w h', h=h),
			FeedForward(h, token_dim, dropout),
			Rearrange('b d w h -> b (h w) d', h=h),
		)

	def forward(self, x):
		x = x + self.w_mix(x)
		x = x + self.h_mix(x)
		x = x + self.channel_mix(x)
		return x

class MLPMDS(nn.Module):
	def __init__(self, in_channels=8, dim=192, num_output=8, patch_size_h=1, patch_size_w=2, image_size_h=32, image_size_w=52, depth=3, token_dim=256, channel_dim=256):
		super().__init__()
		assert image_size_w % patch_size_w == 0, 'Image dimensions must be divisible by the patch size.'
		assert image_size_h % patch_size_h == 0, 'Image dimensions must be divisible by the patch size.'
		self.num_patch =  (image_size_h// patch_size_h) * (image_size_w// patch_size_w)
		self.to_patch_embedding = nn.Sequential(
			nn.Conv2d(in_channels, dim, (patch_size_h, patch_size_w), (patch_size_h, patch_size_w)),
			Rearrange('b c h w -> b (h w) c'),
		)
		self.mixer_blocks = nn.ModuleList([])
		for _ in range(depth):
			self.mixer_blocks.append(MDBlockS(dim, self.num_patch, token_dim, channel_dim, dropout = 0., h =image_size_h,w=image_size_w//patch_size_w))
		self.layer_norm = nn.LayerNorm(dim)
		self.mlp_head = nn.Sequential(
			nn.Linear(dim, num_output)
		)
	def forward(self, x): # (batch, 8, 26, 32)
		x = self.to_patch_embedding(x) # (batch, patch, dim)
		for mixer_block in self.mixer_blocks:
			x = mixer_block(x)
		x = self.layer_norm(x) # (batch, patch, dim)
		#x = x.mean(dim=1)
		return self.mlp_head(x) 