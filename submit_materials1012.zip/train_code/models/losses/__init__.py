from models.losses.loss import *
import torch.nn.functional as F
LOSSES = {
    'MSE_TORCH': F_mse, 
    'COSSIM': cos_sim,
}

def cal_loss_3(name, pred, gt, **kwargs):
    return LOSSES[name](pred, gt, **kwargs)

def cal_loss_4(name, pred, gt, others, **kwargs):
    return LOSSES[name](pred, gt, others, **kwargs)