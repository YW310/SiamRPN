# Copyright (c) SenseTime. All Rights Reserved.

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
import torch
import torch.nn as nn
import torch.nn.functional as F
import math
import numpy as np

def F_mse(input,target,reduction = 'mean'):
	loss = F.mse_loss(input, target, reduction='mean')
	return loss

def cos_sim(w_pre, w_true, reduction='mean'):
	eps = 1e-20
	w_true, w_pre = w_true.permute(0, 3, 2, 1), w_pre.permute(0, 3, 2, 1)
	num_batch, num_sc, num_ant = w_true.size(0), w_true.size(1), w_true.size(2)
	w_true = w_true.reshape(num_batch * num_sc, num_ant, 2)
	w_pre = w_pre.reshape(num_batch * num_sc, num_ant, 2)
	w_true_re, w_true_im = w_true[..., 0], w_true[..., 1]
	w_pre_re, w_pre_im = w_pre[..., 0], w_pre[..., 1]
	numerator_re = (w_true_re * w_pre_re + w_true_im * w_pre_im).sum(-1)
	numerator_im = (w_true_im * w_pre_re - w_true_re * w_pre_im).sum(-1)
	denominator_0 = (w_true_re ** 2 + w_true_im ** 2).sum(-1)
	denominator_1 = (w_pre_re ** 2 + w_pre_im ** 2).sum(-1)
	cos_similarity = torch.sqrt(numerator_re ** 2 + numerator_im ** 2) / (
				torch.sqrt(denominator_0) * torch.sqrt(denominator_1)+eps)
	cos_similarity = cos_similarity ** 2
	return 1 - cos_similarity.mean()