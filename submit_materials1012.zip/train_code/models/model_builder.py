# Copyright (c) SenseTime. All Rights Reserved.

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
from utils.config import cfg
import numpy as np
import torch
import torchvision
import torch.nn as nn
import torch.nn.functional as F
from models.cest import get_cest
from models.csi import get_csi
from models.losses import cal_loss_3, cal_loss_4

def cal_eigenvector(channel):
	"""
		Description:
			calculate the eigenvector on each subband
		Input:
			channel: np.array, channel in frequency domain,  shape [batch_size, rx_num, tx_num, subcarrier_num]
		Output:
			eigenvectors:  np.array, eigenvector for each subband, shape [batch_size, tx_num, subband_num]
	"""
	subband_num = 13
	hf_ = np.transpose(channel, [0,3,1,2]) # (batch,subcarrier_num,4,32)
	hf_h = np.conj(np.transpose(channel, [0,3,2,1])) # (batch,subcarrier_num,32,4)
	R = np.matmul(hf_h, hf_) # (batch,subcarrier_num,32,32)
	R = R.reshape(R.shape[0],subband_num,-1,R.shape[2],R.shape[3]).mean(axis=2) # average the R over each subband, (batch,13,32,32)
	[D,V] = np.linalg.eig(R)
	v = V[:,:,:,0]
	eigenvectors = np.transpose(v,[0,2,1])
	return eigenvectors


def cal_eigenvector_torch(channel, out_type='np'):
	"""
		Description:
			calculate the eigenvector on each subband
		Input:
			channel: np.array, channel in frequency domain,  shape [batch_size, rx_num, tx_num, subcarrier_num]
		Output:
			eigenvectors:  np.array, eigenvector for each subband, shape [batch_size, tx_num, subband_num]
	"""
	subband_num = 13
	hf_ = channel.permute(0,3,1,2) # (batch,52,4,32)
	hf_h = torch.conj(channel.permute(0,3,2,1)) # (batch,subcarrier_num,32,4)
	R = torch.matmul(hf_h, hf_) # (batch,52,32,32)
	R = R.view(R.shape[0],subband_num,-1,R.shape[2],R.shape[3]).mean(axis=2) # average the R over each subband, (batch,13,32,32)
	[D,V] = torch.linalg.eig(R)
	v = V[:,:,:,0]
	eigenvectors = v.transpose(2,1)
	if out_type=='np':
		eigenvectors = eigenvectors.cpu().numpy()
	return eigenvectors


def cal_eigenvector_svd(channel, out_type='np'):
	"""
		Description:
			calculate the eigenvector on each subband
		Input:
			channel: np.array, channel in frequency domain,  shape [batch_size, rx_num, tx_num, subcarrier_num]
		Output:
			eigenvectors:  np.array, eigenvector for each subband, shape [batch_size, tx_num, subband_num]
	"""
	subband_num = 13
	hf_ = channel.permute(0,3,1,2) # (batch,subcarrier_num,4,32)
	hf_h = torch.conj(channel.permute(0,3,2,1)) # (batch,subcarrier_num,32,4)
	R = torch.matmul(hf_h, hf_) # (batch,subcarrier_num,32,32)
	R = R.view(R.shape[0],subband_num,-1,R.shape[2],R.shape[3]).mean(axis=2) # average the R over each subband, (batch,13,32,32)
	[D,V] = torch.linalg.eig(R)
	v = V[:,:,:,0]
	eigenvectors = v.transpose(2,1)
	if out_type=='np':
		eigenvectors = eigenvectors.cpu().numpy()
	return eigenvectors

class ModelBuilder(nn.Module):
	def __init__(self, cest=True,csi=True):
		super(ModelBuilder, self).__init__()
		# build backbone
		self.frame_num = 0
		if cfg.UPS.UPS:
			self.ups = get_cest(cfg.UPS.TYPE,
									 **cfg.UPS.KWARGS)
		
		if cfg.CEST.CEST and cest:
			self.cest = get_cest(cfg.CEST.TYPE,
									 **cfg.CEST.KWARGS)
		if cfg.CSI.CSI and csi:
			self.csi = get_csi(cfg.CSI.TYPE,
									 **cfg.CSI.KWARGS)

	def forward(self, pilot, hf, w, wf=None, pilot_h= None, wf_h_g=None, wf_l_g=None, train_flag=True):
		if torch.cuda.is_available():
			pilot = pilot.cuda()
			HF = hf.cuda()
			W = w.cuda()
			bs = W.shape[0]
		else:
			NotImplementedError
		outputs = {}
		if cfg.TRAIN.TRAIN == 'enc':
			hf_p = self.cest(pilot) # bs,2,4,32,52
			hf_p_nmse = hf_p
			outputs['hf_p'] = hf_p.detach()
			if 'wf' in cfg.TRAIN.PREDICTION:
				hf_p2 = hf_p[:,0,...] + 1j*hf_p[:,1,...]
				wf_temp = cal_eigenvector_torch(hf_p2, out_type='tensor')
				wf = torch.zeros([bs,2,32,13],dtype=torch.float32).cuda()
				wf[:,0,:,:] = torch.real(wf_temp)# 128,2,32,13
				wf[:,1,:,:] = torch.imag(wf_temp)
				outputs['wf_p'] = wf.detach()
				outputs['wf'] = wf.detach()
		elif cfg.TRAIN.TRAIN =='ence2e':
			wf = self.cest(pilot)
			wf_nmse = wf
			outputs['wf'] = wf.detach()
		elif cfg.TRAIN.TRAIN == 'dec':
			if train_flag == False:
				self.csi.set_inference(True)
			else:
				self.csi.set_inference(False)
			if ('wf_h' in cfg.TRAIN.LABEL or 'wf_l' in cfg.TRAIN.LABEL):
				wf = wf.cuda()
			else:
				with torch.no_grad():
					hf_p = self.cest(pilot)
					hf_p = hf_p[:,0,...] + 1j*hf_p[:,1,...] # (batch,4,32,52)
					# wf_temp = cal_eigenvector_torch(hf_p, out_type='tensor')
					wf_temp = cal_eigenvector(hf_p.cpu().numpy())
					wf_temp = torch.from_numpy(wf_temp)
					wf = torch.zeros([bs,2,32,13],dtype=torch.float32).cuda()
					wf[:,0,:,:] = torch.real(wf_temp)
					wf[:,1,:,:] = torch.imag(wf_temp)
					outputs['hf_p'] = hf_p.detach()
			# if train_flag == True:
			# 	if torch.rand(1)<cfg.DATASET.MIXW:
			# 		wf = W
			
			if torch.rand(1)<cfg.DATASET.NOISE and train_flag == True:
				wf_p = self.csi(wf+torch.randn(wf.shape).cuda()*cfg.DATASET.NOISEVAL)
			else:
				wf_p = self.csi(wf)
			wf_p_gt = wf_p
			wf_p_mse = wf_p
			outputs['wf_p'] = wf_p.detach()
			outputs['wf'] = wf.detach()
		elif cfg.TRAIN.TRAIN == 'dec_wo_cest':
			wf_p = self.csi(W)
			wf_p_gt = wf_p
			wf_p_mse = wf_p
			outputs['wf_p'] = wf_p.detach()
		elif cfg.TRAIN.TRAIN == 'casdec':
			if ('wf_h' in cfg.TRAIN.LABEL or 'wf_l' in cfg.TRAIN.LABEL):
				wf = wf.cuda()
			else:
				with torch.no_grad():
					hf_p = self.cest(pilot)
					hf_p = hf_p[:,0,...] + 1j*hf_p[:,1,...] # (batch,4,32,52)
					# wf_temp = cal_eigenvector_torch(hf_p, out_type='tensor')
					wf_temp = cal_eigenvector(hf_p.cpu().numpy())
					wf_temp = torch.from_numpy(wf_temp)
					wf = torch.zeros([bs,2,32,13],dtype=torch.float32).cuda()
					wf[:,0,:,:] = torch.real(wf_temp)
					wf[:,1,:,:] = torch.imag(wf_temp)	
					outputs['hf_p'] = hf_p.detach()

			if cfg.DATASET.LTSPOT.LTSPOT>0.0 and train_flag == True:
				if cfg.CEST.KWARGS.input_length == 208 or cfg.CEST.KWARGS.input_length == 416:
					wf_g = wf_h_g
				elif cfg.CEST.KWARGS.input_length == 48 or cfg.CEST.KWARGS.input_length == 96:
					wf_g = wf_l_g
				wf_g = wf_g.cuda()
				if torch.rand(1)<cfg.DATASET.NOISE and train_flag == True:
					wf_p_0 = self.csi(wf_g+torch.randn(wf.shape).cuda()*cfg.DATASET.NOISEVAL)
				else:
					wf_p_0 = self.csi(wf_g)
			else:
				if torch.rand(1)<cfg.DATASET.NOISE and train_flag == True:
					wf_p_0 = self.csi(wf+torch.randn(wf.shape).cuda()*cfg.DATASET.NOISEVAL)
				else:
					wf_p_0 = self.csi(wf)

			wf_p_0_mse = wf_p_0
			if 'wf_p' in cfg.TRAIN.PREDICTION:
				wf_p = self.csi(W)
			if 'wf_p_1' in cfg.TRAIN.PREDICTION:
				wf_p_1 = self.csi(wf_p_0)
				wf_p_1_cas = wf_p_1
				if 'wf_p_2' in cfg.TRAIN.PREDICTION:
					wf_p_2 = self.csi(wf_p_1)
					wf_p_2_cas = wf_p_2
			wf_p_0_W = wf_p_0
			
			
			outputs['wf_p'] = wf_p_0.detach()
			# outputs['wf_p_0'] = wf_p_0.detach()
			# outputs['wf_p_1'] = wf_p_1.detach()
			# outputs['wf_p_2'] = wf_p_2.detach()
			# outputs['wf'] = wf.detach()
		elif cfg.TRAIN.TRAIN == 'joint':
			if train_flag == False:
				self.csi.set_inference(True)
			else:
				self.csi.set_inference(False)
			hf_p = self.cest(pilot)
			hf_p2 = hf_p[:,0,...] + 1j*hf_p[:,1,...]
			wf_temp = cal_eigenvector_torch(hf_p2, out_type='tensor')
			wf = torch.zeros([bs,2,32,13],dtype=torch.float32).cuda()
			wf[:,0,:,:] = torch.real(wf_temp)# 128,2,32,13
			wf[:,1,:,:] = torch.imag(wf_temp)
			wf_p = self.csi(wf)
			wf_p_gt = wf_p
			wf_p_mse = wf_p
			outputs['wf_p'] = wf_p.detach()
			outputs['wf'] = wf.detach()
		elif cfg.TRAIN.TRAIN == 'ups':
			pass
		else: #others
			NotImplementedError
		
		# supervised learning
		preds = []
		gts = []
		for val in cfg.TRAIN.PREDICTION:
			exec("preds.append(%s)"%(val))
		for gt in cfg.TRAIN.GT:
			gt_temp = []
			for val in gt:
				exec("gt_temp.append(%s)"%(val))
			gts.append(gt_temp)
		
		total_loss,losses = self.cal_total_loss(preds,gts)
		outputs['total_loss'] = total_loss
		for idx, val in enumerate(cfg.TRAIN.PREDICTION):
			outputs['l_'+val]=losses[idx]
		
		return outputs
	
	def cal_total_loss(self, pred, gts):
		losses = []
		for i in range(len(gts)):
			loss_name = cfg.TRAIN.LOSS[i]
			kwargs = cfg.LOSS[loss_name].KWARGS
			exec_command =''
			if (1==len(gts[i])):
				exec_command = "losses.append(cal_loss_3(loss_name,pred[i]"
			else:
				exec_command = "losses.append(cal_loss_4(loss_name,pred[i]"
			for j in range(len(gts[i])):
				exec_command = exec_command + ",gts[i][%d]"%(j)
			exec_command += ",**kwargs))"
			exec(exec_command)
		total_loss = 0
		for i in range(len(gts)):
			w = cfg.TRAIN.WEIGHT[i]
			total_loss += w*losses[i]
			
		return total_loss,losses