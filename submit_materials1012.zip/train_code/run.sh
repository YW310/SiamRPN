ln -s ../user_data .
ln -s ../raw_data Data
cd exp/enc
# CE 
echo 'start c48 s0 training stage'
python -m torch.distributed.launch --nproc_per_node=2 --master_port=2337 ../../train.py --config 'config_c48_s0.yaml'
echo 'start c48 s1 training stage'
python -m torch.distributed.launch --nproc_per_node=2 --master_port=2337 ../../train.py --config 'config_c48_s1.yaml'
echo 'start c208 s0 training stage'
python -m torch.distributed.launch --nproc_per_node=2 --master_port=2337 ../../train.py --config 'config_c208_s0.yaml'
echo 'start c208 s1 training stage'
python -m torch.distributed.launch --nproc_per_node=2 --master_port=2337 ../../train.py --config 'config_c208_s1.yaml'
# gene wf
python gene_wf.py
# train CSI 
cd exp/dec
echo 'start s0 training stage'
python -m torch.distributed.launch --nproc_per_node=4 --master_port=2337 ../../train.py --config 'config_s0.yaml'
echo 'start s1 training stage'
python -m torch.distributed.launch --nproc_per_node=4 --master_port=2337 ../../train.py --config 'config_s1.yaml'
# echo 'start s1b training stage'
# python -m torch.distributed.launch --nproc_per_node=4 --master_port=2337 ../../train.py --config 'config_s1b.yaml'
echo 'start s2 training stage'
python -m torch.distributed.launch --nproc_per_node=4 --master_port=2337 ../../train.py --config 'config_s2.yaml'
# gene model
python gene_model.py --config 'exp/joint/config_c48.yaml' --output_path 'user_data'
python gene_model.py --config 'exp/joint/config_c208.yaml' --output_path 'user_data'


