import os
import sys
sys.path.append('/home/sr5/yiwei.chen/transwaic/')
import six
import string
import argparse

import lmdb
import pickle
import msgpack
import tqdm
from PIL import Image
import numpy as np
import torch
import torch.utils.data as data
from torch.utils.data import DataLoader
from torchvision.transforms import transforms
from torchvision import transforms, datasets
# This segfaults when imported before torch: https://github.com/apache/arrow/issues/2637
import pyarrow as pa
from utils.config import cfg

class DatasetFolder(data.Dataset):
	def __init__(self, p_h, p_l, hf, w):
		self.pilot_h, self.pilot_l, self.label_hf,self.label_w = p_h, p_l, hf, w
	def __getitem__(self, index):
		return self.pilot_h[index], self.pilot_l[index], self.label_hf[index], self.label_w[index]
	def __len__(self):
		return self.pilot_h.shape[0]

class DatasetFolderWF(data.Dataset):
	def __init__(self, wf, w):
		self.label_wf, self.label_w = wf, w
	def __getitem__(self, index):
		return self.label_wf[index], self.label_w[index]
	def __len__(self):
		return self.label_w.shape[0]


class ImageFolderLMDB(data.Dataset):
	def __init__(self, db_path, transform=None, target_transform=None):
		self.db_path = db_path
		self.env = lmdb.open(db_path, subdir=os.path.isdir(db_path),
							 readonly=True, lock=False,
							 readahead=False, meminit=False)
		with self.env.begin(write=False) as txn:
			# self.length = txn.stat()['entries'] - 1
			self.length = pa.deserialize(txn.get(b'__len__'))
			self.keys = pa.deserialize(txn.get(b'__keys__'))
		
		
		# videos_per_epoch = cfg.DATASET.VIDEOS_PER_EPOCH
		# self.length = videos_per_epoch if videos_per_epoch > 0 else self.length
		# self.length *= cfg.TRAIN.EPOCH

		self.transform = transform
		self.target_transform = target_transform

	def __getitem__(self, index):
		env = self.env
		with env.begin(write=False) as txn:
			byteflow = txn.get(self.keys[index])
		unpacked = pa.deserialize(byteflow)

		pilot_h = unpacked[0]
		pilot_l = unpacked[1]
		hf = unpacked[2]
		w = unpacked[3]
		
		return pilot_h, pilot_l, hf, w

	def __len__(self):
		return self.length

	def __repr__(self):
		return self.__class__.__name__ + ' (' + self.db_path + ')'


def raw_reader(path):
	with open(path, 'rb') as f:
		bin_data = f.read()
	return bin_data


def dumps_pyarrow(obj):
	"""
	Serialize an object.
	Returns:
		Implementation-dependent bytes-like object
	"""
	return pa.serialize(obj).to_buffer()


def folder2lmdb(wf_path, w_path, outpath, write_frequency=5000):
	hf = np.load(hf_path)['data']
	hf = np.expand_dims(hf, axis=1)
	hf = np.concatenate([np.real(hf), np.imag(hf)], 1)
	# hf = hf[:10000]

	# load eigenvector
	wf = np.load(wf_path)['data']
	wf = np.expand_dims(wf, axis=1)
	wf = np.concatenate([np.real(wf), np.imag(wf)], 1)
	#
	w = np.load(w_path)['data']
	w = np.expand_dims(w, axis=1)
	w = np.concatenate([np.real(w), np.imag(w)], 1)
	

	split_idx = int(0.95 * w.shape[0])
	w_train, w_val = w[:split_idx,...], w[split_idx:,...]
	# Train
	train_output = os.path.join(outpath,'train')
	dataset_train = DatasetFolder(wf_train, w_train)
	train_data_loader = DataLoader(dataset_train, num_workers=16, collate_fn=lambda x: x)
	train_lmdb_path = os.path.expanduser(train_output)
	print("Generate LMDB to %s" % train_lmdb_path)
	train_db = lmdb.open(train_lmdb_path, subdir=os.path.isdir(train_lmdb_path),
				   map_size=1099511627776 * 2, readonly=False,
				   meminit=False, map_async=True)

	txn = train_db.begin(write=True)
	for idx, data in enumerate(train_data_loader):
		p_h, p_l, label_hf, label_w = data[0]
		txn.put(u'{}'.format(idx).encode('ascii'), dumps_pyarrow((p_h, p_l, label_hf,label_w)))
		if idx % write_frequency == 0:
			print("[%d/%d]" % (idx, len(train_data_loader)))
			txn.commit()
			txn = train_db.begin(write=True)
	# finish iterating through dataset
	txn.commit()
	keys = [u'{}'.format(k).encode('ascii') for k in range(idx + 1)]
	with train_db.begin(write=True) as txn:
		txn.put(b'__keys__', dumps_pyarrow(keys))
		txn.put(b'__len__', dumps_pyarrow(len(keys)))
	train_db.sync()
	train_db.close()
	print("Flushing train database ...")
	# Val
	val_output = os.path.join(outpath,'val')
	val_dataset = DatasetFolder(pilot_h_val, pilot_l_val, hf_val, w_val)
	val_data_loader = DataLoader(val_dataset, num_workers=16, collate_fn=lambda x: x)
	val_lmdb_path = os.path.expanduser(val_output)
	print("Generate LMDB to %s" % val_lmdb_path)
	val_db = lmdb.open(val_lmdb_path, subdir=os.path.isdir(val_lmdb_path),
				   map_size=1099511627776 * 2, readonly=False,
				   meminit=False, map_async=True)

	txn = val_db.begin(write=True)
	for idx, data in enumerate(val_data_loader):
		p_h, p_l, label_hf, label_w = data[0]
		txn.put(u'{}'.format(idx).encode('ascii'), dumps_pyarrow((p_h, p_l, label_hf,label_w)))
		if idx % write_frequency == 0:
			print("[%d/%d]" % (idx, len(val_data_loader)))
			txn.commit()
			txn = val_db.begin(write=True)
	# finish iterating through dataset
	txn.commit()
	keys = [u'{}'.format(k).encode('ascii') for k in range(idx + 1)]
	with val_db.begin(write=True) as txn:
		txn.put(b'__keys__', dumps_pyarrow(keys))
		txn.put(b'__len__', dumps_pyarrow(len(keys)))
	val_db.sync()
	val_db.close()
	print("Flushing val database ...")

if __name__ == "__main__":
	parser = argparse.ArgumentParser()
	parser.add_argument("--w", default="Data/w.npz",help="Path to original image dataset folder")
	parser.add_argument("--wf", default="Data/wf.npz",help="Path to original image dataset folder")
	parser.add_argument("--outpath", default="waic",help="Path to output LMDB file")
	args = parser.parse_args()
	folder2lmdb(args.wf,args.w, args.outpath)